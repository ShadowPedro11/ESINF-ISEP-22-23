import domain.*;
import org.junit.Assert;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.TreeSet;

public class CountriesListedTest {

    final String path1 = "src/main/resources/FAOSTAT_data_en_9-7-2022_SMALL.csv";
    final String path2 = "src/main/resources/FAOSTAT_data_en_9-7-2022_BIG.csv";
    @Test
    public void testCountriesList1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Item fruit = new Item(5510, "Production", 515, "Apples");
        long quantity = 3900000;
        LinkedList<FruitProduction> countries = CountriesListed.countriesListLowestYear(fileIO.getContainer(),fileIO.countriesNProductions.keySet() ,fruit, quantity);

        LinkedList<FruitProduction> expected = new LinkedList<>();
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",68,"France"), new Item(5510,"Production",515,"Apples"), new Year(1962, 1962), new Value("tonnes",5050000L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",228,"USSR"), new Item(5510,"Production",515,"Apples"), new Year(1970,1970), new Value("tonnes",5046000L),"*","Unofficial figure" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",231,"United States of America"), new Item(5510,"Production",515,"Apples"), new Year(1980,1980), new Value("tonnes",4000000L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",41,"China, mainland"), new Item(5510,"Production",515,"Apples"), new Year(1987, 1987), new Value("tonnes",4265000L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",173,"Poland"), new Item(5510,"Production",515,"Apples"), new Year(2018, 2018), new Value("tonnes",3999520L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",223,"Türkiye"), new Item(5510,"Production",515,"Apples"), new Year(2020, 2020), new Value("tonnes",4300486L),"","Official data" ));

        Assert.assertEquals(expected, countries);
    }

    @Test
    public void testCountriesList2() throws FileNotFoundException {
        LinkedList<FruitProduction> countries;
        FileIO fileIO = new FileIO(path1);
        Item fruit = new Item(5510, "Production", 515, "Apples");
        int quantity = 100;

        countries = CountriesListed.countriesListLowestYear(fileIO.getContainer(), fileIO.countriesNProductions.keySet() ,fruit, quantity);

        LinkedList<FruitProduction> expected = new LinkedList<>();
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",203,"Spain"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",917409L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));

        Assert.assertEquals(expected, countries);
    }

    @Test
    public void testCountriesList3() throws FileNotFoundException {
        LinkedList<FruitProduction> countries;
        FileIO fileIO = new FileIO(path1);
        Item fruit = new Item(5510, "Production", 515, "Apples");
        int quantity = 100000000;

        countries = CountriesListed.countriesListLowestYear(fileIO.getContainer(), fileIO.countriesNProductions.keySet() ,fruit, quantity);

        LinkedList<FruitProduction> expected = new LinkedList<>();

        Assert.assertEquals(expected, countries);
    }

    @Test
    public void testCountriesList4() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        LinkedList<FruitProduction> countries;
        Item fruit = new Item(5510, "Production", 515, "Apples");
        int quantity = 100;

        countries = CountriesListed.countriesListLowestYear(new ArrayList<FruitProduction>(), fileIO.countriesNProductions.keySet(), fruit, quantity);

        LinkedList<String> expected = new LinkedList<>();

        Assert.assertEquals(expected, countries);
    }

    @Test
    public void testCountriesList5() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        LinkedList<FruitProduction> countries;
        Item fruit = new Item(5510, "Production", 515, "Apples");
        int quantity = 100;

        countries = CountriesListed.countriesListLowestYear(null, fileIO.countriesNProductions.keySet(), fruit, quantity);

        LinkedList<String> expected = null;

        Assert.assertEquals(expected, countries);
    }

    @Test
    public void testCountriesList6() throws FileNotFoundException {
        LinkedList<FruitProduction> countries;
        FileIO fileIO = new FileIO(path1);
        Item fruit = null;
        int quantity = 100;

        countries = CountriesListed.countriesListLowestYear(fileIO.getContainer(), fileIO.countriesNProductions.keySet(), fruit, quantity);

        LinkedList<String> expected = null;

        Assert.assertEquals(expected, countries);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Test
    public void minimumYearWithProductionQ1() {
        int quantity = 1000000;
        TreeSet<FruitProduction> test = new TreeSet<>(new FruitProductionComparator());
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",258364L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",258365L),"","Official data" ));

        FruitProduction actual = CountriesListed.lowestYearWithProductionQ(test, quantity);
        Assert.assertEquals(null, actual);
    }

    @Test
    public void minimumYearWithProductionQ2() {
        FruitProduction actual = domain.CountriesListed.lowestYearWithProductionQ(new TreeSet<>(), 1);

        Assert.assertEquals(null, actual);
    }

    @Test
    public void minimumYearWithProductionQ3() {
        int quantity = 100;
        TreeSet<FruitProduction> test = new TreeSet<>(new FruitProductionComparator());
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",258364L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",258365L),"","Official data" ));

        FruitProduction expected = new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",258364L),"","Official data" );

        FruitProduction actual = CountriesListed.lowestYearWithProductionQ(test, quantity);
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void minimumYearWithProductionQ4() {
        int quantity = 290000;
        TreeSet<FruitProduction> test = new TreeSet<>(new FruitProductionComparator());
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",200L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",300000L),"","Official data" ));
        test.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2004,2004), new Value("tonnes",258365L),"","Official data" ));

        FruitProduction expected = new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",300000L),"","Official data" );

        FruitProduction actual = CountriesListed.lowestYearWithProductionQ(test, quantity);
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void minimumYearWithProductionQ5() {
        int quantity = 290000;
        TreeSet<FruitProduction> test = null;
        FruitProduction expected = null;

        FruitProduction actual = CountriesListed.lowestYearWithProductionQ(test, quantity);
        Assert.assertEquals(expected, actual);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Test
    public void productionsPerCountry1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Item fruit = new Item(5510, "Production", 515, "Apples");
        TreeSet<FruitProduction> actual = CountriesListed.fruitProductionsPerCountryOfFruitF(fileIO.getContainer(), fruit, "Portugal");
        TreeSet<FruitProduction> expected = new TreeSet<>(new FruitProductionComparator());
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2000,2000), new Value("tonnes",229794L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",300225L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",284971L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2004,2004), new Value("tonnes",275123L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2005,2005), new Value("tonnes",250543L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2006,2006), new Value("tonnes",256618L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2007,2007), new Value("tonnes",245471L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2008,2008), new Value("tonnes",237011L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2009,2009), new Value("tonnes",263146L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2010,2010), new Value("tonnes",212902L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2011,2011), new Value("tonnes",247229L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2012,2012), new Value("tonnes",220761L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2013,2013), new Value("tonnes",287314L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2014,2014), new Value("tonnes",273721L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2015,2015), new Value("tonnes",324994L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2016,2016), new Value("tonnes",241611L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2017,2017), new Value("tonnes",329371L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2018,2018), new Value("tonnes",263960L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2019,2019), new Value("tonnes",370710L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2020,2020), new Value("tonnes",286080L),"","Official data" ));

        Assert.assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void productionsPerCountry2(){
        Item fruit = new Item(5510, "Production", 515, "Apples");
        TreeSet<FruitProduction> expected = new TreeSet<>();
        TreeSet<FruitProduction> actual = CountriesListed.fruitProductionsPerCountryOfFruitF(new ArrayList<>(), fruit, "Portugal");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void productionsPerCountry3(){
        ArrayList<FruitProduction> test = null;
        Item fruit = new Item(5510, "Production", 515, "Apples");
        TreeSet<FruitProduction> expected = null;
        TreeSet<FruitProduction> actual = CountriesListed.fruitProductionsPerCountryOfFruitF(test, fruit, "Portugal");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void productionsPerCountry4() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        ArrayList<FruitProduction> test = fileIO.getContainer();
        Item fruit = null;
        TreeSet<FruitProduction> expected = null;
        TreeSet<FruitProduction> actual = CountriesListed.fruitProductionsPerCountryOfFruitF(test, fruit, "Portugal");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void productionsPerCountry5() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        ArrayList<FruitProduction> test = fileIO.getContainer();
        Item fruit = new Item(5510, "Production", 515, "Apples");
        TreeSet<FruitProduction> expected = null;
        TreeSet<FruitProduction> actual = CountriesListed.fruitProductionsPerCountryOfFruitF(test, fruit, null);

        Assert.assertEquals(expected, actual);
    }
}