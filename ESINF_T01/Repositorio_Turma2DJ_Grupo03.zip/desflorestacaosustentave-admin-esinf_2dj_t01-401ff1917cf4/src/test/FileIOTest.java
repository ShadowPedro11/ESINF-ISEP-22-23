import domain.FruitProduction;
import domain.FileIO;
import org.junit.Assert;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : Ricardo Venâncio - 1210828
 * @author : Pedro Pereira - 1211131
 **/
public class FileIOTest {


    FileIO fp1 = new FileIO();
    FileIO fp2 = new FileIO();
    final String path1 = "src/main/resources/FAOSTAT_data_en_9-7-2022_SMALL.csv";
    final String path2 = "src/main/resources/FAOSTAT_data_en_9-7-2022_BIG.csv";

    @Test
    public void testNullPath() throws FileNotFoundException {
        String nullPath = null;

        boolean result = fp1.readCSV(nullPath);

        Assert.assertFalse(result);
    }

    @Test
    public void testInvalidPath() throws FileNotFoundException {
        String invalidPath = "src/main/resources/INVALID_PATH_FAOSTAT_data_en_9-7-2022_BIG.csv";

        boolean result = fp1.readCSV(invalidPath);

        Assert.assertFalse(result);
    }

    @Test
    public void testDataImportSizeSmall() throws FileNotFoundException {

        List<FruitProduction> container;

        container = fp1.getContainer();

        container.clear();
        fp1.readCSV(path1);

        int expected = 84;
        int result = container.size();

        Assert.assertEquals(expected, result);


    }

    @Test
    public void testDataImportSizeBig() throws FileNotFoundException {

        ArrayList<FruitProduction> container2;

        container2 = fp2.getContainer();
        container2.clear();

        fp2.readCSV(path2);

        int expected = 17601;
        int result = container2.size();

        Assert.assertEquals(expected, result);

    }

    @Test
    public void testDataImportContentSmall() throws FileNotFoundException {

        ArrayList<FruitProduction> container = fp1.getContainer();
        container.clear();

        fp1.readCSV(path1);

        String expected = "QCL,Crops and livestock products,174,Portugal,5510,Production,486,Bananas,2001,2001,tonnes,28304,,Official data";

        String result = container.get(22).toString();

        Assert.assertEquals(expected, result);

        expected = "QCL,Crops and livestock products,203,Spain,5510,Production,515,Apples,2005,2005,tonnes,774210,,Official data";

        result = container.get(47).toString();

        Assert.assertEquals(expected, result);
    }

    @Test
    public void testDataImportContentBig() throws FileNotFoundException {

        fp2 = new FileIO();
        ArrayList<FruitProduction> container2 = fp2.getContainer();
        container2.clear();

        fp2.readCSV(path2);
        String expected = "QCL,Crops and livestock products,68,France,5510,Production,531,Cherries,2019,2019,tonnes,32120,,Official data";

        String result = container2.get(5608).toString();

        Assert.assertEquals(expected, result);

        expected = "QCL,Crops and livestock products,134,Malta,5510,Production,552,Blueberries,2020,2020,tonnes,0,,Official data";

        result = container2.get(9966).toString();

        Assert.assertEquals(expected, result);
    }


}
