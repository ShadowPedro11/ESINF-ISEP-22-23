import domain.FruitProduction;
import domain.MinimumCountries;
import domain.FileIO;
import domain.Value;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Map;

public class MinimumCountriesTest {

    FileIO fp1;
    FileIO fp2;
    MinimumCountries mc;

    ArrayList<FruitProduction> container1;
    ArrayList<FruitProduction> container2;

    Map<String, ArrayList<Long>> c1;

    Map<String, ArrayList<Long>> c2;

    final String PATH_1 = "src/main/resources/FAOSTAT_data_en_9-7-2022_SMALL.csv";
    final String PATH_2 = "src/main/resources/FAOSTAT_data_en_9-7-2022_BIG.csv";
    final static long MAX_1 = 28154945;
    final static long MAX_2 = 6641441687L;
    final static long PORTUGAL_PRODUCTION_1 = 6176185;
    final static long SPAIN_PRODUCTION_1 = MAX_1 - PORTUGAL_PRODUCTION_1;
    final static long EL_SALVADOR_PRODUCTION_2 = 468584;
    final static String UNIT = "tonnes";

    @Before
    public void setUp() throws FileNotFoundException {
        fp1 = new FileIO();
        fp2 = new FileIO();

        fp1.readCSV(PATH_1);
        fp2.readCSV(PATH_2);

        mc = new MinimumCountries();

        container1 = fp1.getContainer();
        container2 = fp2.getContainer();

        c1 = fp1.countriesNProductions;
        c2 = fp2.countriesNProductions;
    }

    @Test
    public void testIfNeitherAllCountriesTogetherProduceQ(){

        Value v = new Value(UNIT, MAX_1+1);

        Integer expected = 0;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c1);

        Assert.assertEquals(expected, result);

        v = new Value(UNIT, MAX_2+1);

        result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);

    }

    @Test
    public void testIfQIsGreaterThanOneCountryButLesserThanOther(){

        Value v = new Value(UNIT, PORTUGAL_PRODUCTION_1+1);

        Integer expected = 1;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c1);

        Assert.assertEquals(expected, result);


        v = new Value(UNIT, EL_SALVADOR_PRODUCTION_2+1);

        result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void testIfQIsGreaterThanTheCountryThatMostProduces(){

        Value v = new Value(UNIT, SPAIN_PRODUCTION_1+1);

        Integer expected = 2;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c1);

        Assert.assertEquals(expected, result);


        v = new Value(UNIT, 1100000000L);

        result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void assertMethodWorksProperly(){

        Value v = new Value(UNIT, 6641441680L);

        Integer expected = 184;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);

        v = new Value(UNIT, 1200000000L);

        expected = 2;

        result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);

        v = new Value(UNIT, 2300000000L);

        expected = 4;

        result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void assertInvalidQuantityDoesntWork(){
        Value v = new Value(UNIT, -1403L);

        Integer expected = -1;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, c2);

        Assert.assertEquals(expected, result);
    }

    @Test
    public void assertNoDataDoesntWork(){
        Value v = new Value(UNIT, 10L);

        Integer expected = -1;

        FileIO fileIO = new FileIO();

        Map<String, ArrayList<Long>> emptyContainer = fileIO.countriesNProductions;

        Integer result = mc.smallestNumberOfCountriesToProduceMoreThanQ(v, emptyContainer);

        Assert.assertEquals(expected, result);
    }
}
