import domain.*;
import junit.framework.TestCase;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class BiggestAbsoluteDifferenceTest extends TestCase {

    final String path1 = "src/main/resources/FAOSTAT_data_en_9-7-2022_SMALL.csv";
    final String path2 = "src/main/resources/FAOSTAT_data_en_9-7-2022_BIG.csv";

    public void testParOfYearFruitAndHighestAbsolutValuePath1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        String actual = BiggestAbsoluteDifference.pairOfYearFruitAndHighestAbsolutValue(a, fileIO.getContainer());
        String expected = "[2010/2019,Apples,157808]";
        assertEquals(expected, actual);
    }

    public void testParOfYearFruitAndHighestAbsolutValueNullContainer() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        String actual = BiggestAbsoluteDifference.pairOfYearFruitAndHighestAbsolutValue(a, new ArrayList<>());
        String expected = "";
        assertEquals(expected, actual);
    }

    public void testParOfYearFruitAndHighestAbsolutValuePath2() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        String actual = BiggestAbsoluteDifference.pairOfYearFruitAndHighestAbsolutValue(a, fileIO.getContainer());
        String expected = "[1962/2019,Apples,312710]";
        assertEquals(expected, actual);
    }

    public void testParOfYearFruitAndHighestAbsolutValueNullArea() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("","",0, "");
        String actual = BiggestAbsoluteDifference.pairOfYearFruitAndHighestAbsolutValue(a, fileIO.getContainer());
        String expected = "";
        assertEquals(expected, actual);
    }

    public void testGetFruitListPath1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        TreeSet<String> actual = BiggestAbsoluteDifference.getFruitList(a, fileIO.getContainer());
        TreeSet<String> expected = new TreeSet<>();
        expected.add("Apples");
        expected.add("Bananas");
        assertEquals(expected, actual);
    }

    public void testGetFruitListPath2() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        TreeSet<String> actual = BiggestAbsoluteDifference.getFruitList(a, fileIO.getContainer());
        TreeSet<String> expected = new TreeSet<>();
        expected.add("Apples");
        expected.add("Bananas");
        expected.add("Blueberries");
        expected.add("Cherries");
        assertEquals(expected, actual);
    }

    public void testGetFruitListNullContainer() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        TreeSet<String> actual = BiggestAbsoluteDifference.getFruitList(a, new ArrayList<>());
        TreeSet<String> expected = new TreeSet<>();
        assertEquals(expected, actual);
    }

    public void testGetFruitListNullArea() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("","",0, "");;
        TreeSet<String> actual = BiggestAbsoluteDifference.getFruitList(a, fileIO.getContainer());
        TreeSet<String> expected = new TreeSet<>();
        assertEquals(expected, actual);
    }


    public void testGetListAreaFruitPath1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        ArrayList<FruitProduction> actual = BiggestAbsoluteDifference.getListAreaFruit("Apples",a , fileIO.getContainer());
        ArrayList<FruitProduction> expected = new ArrayList<>();

        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2000,2000), new Value("tonnes",229794L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",300225L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",284971L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2004,2004), new Value("tonnes",275123L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2005,2005), new Value("tonnes",250543L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2006,2006), new Value("tonnes",256618L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2007,2007), new Value("tonnes",245471L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2008,2008), new Value("tonnes",237011L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2009,2009), new Value("tonnes",263146L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2010,2010), new Value("tonnes",212902L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2011,2011), new Value("tonnes",247229L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2012,2012), new Value("tonnes",220761L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2013,2013), new Value("tonnes",287314L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2014,2014), new Value("tonnes",273721L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2015,2015), new Value("tonnes",324994L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2016,2016), new Value("tonnes",241611L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2017,2017), new Value("tonnes",329371L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2018,2018), new Value("tonnes",263960L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2019,2019), new Value("tonnes",370710L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2020,2020), new Value("tonnes",286080L),"","Official data" ));

        assertEquals(expected, actual);
    }

    public void testGetListAreaFruitPath2() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        ArrayList<FruitProduction> actual = BiggestAbsoluteDifference.getListAreaFruit("Apples",a , fileIO.getContainer());
        ArrayList<FruitProduction> expected = new ArrayList<>();

        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1961,1961), new Value("tonnes",70000L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1962,1962), new Value("tonnes",58000L),"*","Unofficial figure"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1963,1963), new Value("tonnes",92000L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1964,1964), new Value("tonnes",85000L),"*","Unofficial figure"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1965,1965), new Value("tonnes",96000L),"*","Unofficial figure"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1966,1966), new Value("tonnes",86533L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1967,1967), new Value("tonnes",90501L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1968,1968), new Value("tonnes",71400L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1969,1969), new Value("tonnes",82399L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1970,1970), new Value("tonnes",88730L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1971,1971), new Value("tonnes",95120L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1972,1972), new Value("tonnes",114790L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1973,1973), new Value("tonnes",142910L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1974,1974), new Value("tonnes",122176L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1975,1975), new Value("tonnes",140503L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1976,1976), new Value("tonnes",154553L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1977,1977), new Value("tonnes",94471L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1978,1978), new Value("tonnes",117382L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1979,1979), new Value("tonnes",107385L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1980,1980), new Value("tonnes",127644L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1981,1981), new Value("tonnes",97000L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1982,1982), new Value("tonnes",104800L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1983,1983), new Value("tonnes",115280L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1984,1984), new Value("tonnes",86460L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1985,1985), new Value("tonnes",95100L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1986,1986), new Value("tonnes",238560L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1987,1987), new Value("tonnes",249775L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1988,1988), new Value("tonnes",241880L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1989,1989), new Value("tonnes",265782L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1990,1990), new Value("tonnes",282521L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1991,1991), new Value("tonnes",263350L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1992,1992), new Value("tonnes",281033L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1993,1993), new Value("tonnes",264122L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1994,1994), new Value("tonnes",212015L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1995,1995), new Value("tonnes",234897L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1996,1996), new Value("tonnes",256712L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1997,1997), new Value("tonnes",285716L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1998,1998), new Value("tonnes",160074L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(1999,1999), new Value("tonnes",295000L),"","Official data"));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2000,2000), new Value("tonnes",229794L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2001,2001), new Value("tonnes",258363L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2002,2002), new Value("tonnes",300225L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2003,2003), new Value("tonnes",284971L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2004,2004), new Value("tonnes",275123L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2005,2005), new Value("tonnes",250543L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2006,2006), new Value("tonnes",256618L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2007,2007), new Value("tonnes",245471L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2008,2008), new Value("tonnes",237011L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2009,2009), new Value("tonnes",263146L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2010,2010), new Value("tonnes",212902L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2011,2011), new Value("tonnes",247229L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2012,2012), new Value("tonnes",220761L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2013,2013), new Value("tonnes",287314L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2014,2014), new Value("tonnes",273721L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2015,2015), new Value("tonnes",324994L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2016,2016), new Value("tonnes",241611L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2017,2017), new Value("tonnes",329371L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2018,2018), new Value("tonnes",263960L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2019,2019), new Value("tonnes",370710L),"","Official data" ));
        expected.add(new FruitProduction(new Area("QCL","Crops and livestock products",174,"Portugal"), new Item(5510,"Production",515,"Apples"), new Year(2020,2020), new Value("tonnes",286080L),"","Official data" ));

        assertEquals(expected, actual);
    }

    public void testGetListAreaFruitNullContainer() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        ArrayList<FruitProduction> actual = BiggestAbsoluteDifference.getListAreaFruit("Apples",a , new ArrayList<>());
        ArrayList<FruitProduction> expected = new ArrayList<>();

        assertEquals(expected, actual);
    }

    public void testGetListAreaFruitNullArea() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = null;
        ArrayList<FruitProduction> actual = BiggestAbsoluteDifference.getListAreaFruit("Apples",a , new ArrayList<>());
        ArrayList<FruitProduction> expected = new ArrayList<>();

        assertEquals(expected, actual);
    }

    public void testGetBiggestDiffPath1() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path1);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        Map<Long,String> actual = BiggestAbsoluteDifference.getBiggestDiff(BiggestAbsoluteDifference.getListAreaFruit("Apples", a, fileIO.getContainer()));
        Map<Long,String> expected = new HashMap<>();
        expected.put(157808L, "2010/2019");

        assertEquals(expected, actual);

    }

    public void testGetBiggestDiffPath2() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        Map<Long,String> actual = BiggestAbsoluteDifference.getBiggestDiff(BiggestAbsoluteDifference.getListAreaFruit("Apples", a, fileIO.getContainer()));
        Map<Long,String> expected = new HashMap<>();
        expected.put(312710L, "1962/2019");

        assertEquals(expected, actual);

    }

    public void testGetBiggestDiffNullList() throws FileNotFoundException {
        FileIO fileIO = new FileIO(path2);
        Area a = new Area("QCL","Crops and livestock products",174, "Portugal");
        Map<Long,String> actual = BiggestAbsoluteDifference.getBiggestDiff(new ArrayList<>());
        Map<Long,String> expected = new HashMap<>();
        expected.put(0L,"");

        assertEquals(expected, actual);

    }


}