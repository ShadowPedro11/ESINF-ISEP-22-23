import domain.*;
import junit.framework.TestCase;
import org.junit.Assert;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MaxConsecutivePositiveIncreaseYearsTest extends TestCase {

    FileIO fp1;
    FileIO fp2;
    final String path1 = "src/main/resources/FAOSTAT_data_en_9-7-2022_SMALL.csv";
    final String path2 = "src/main/resources/FAOSTAT_data_en_9-7-2022_BIG.csv";
    MaxConsecutivePositiveIncreaseYears maxConsecutivePositiveIncreaseYears = new MaxConsecutivePositiveIncreaseYears();


    public void testCountriesWithMaxConsecutivePositiveIncreaseYearsOfFruitF() throws FileNotFoundException {
        fp1 = new FileIO();
        ArrayList<FruitProduction> container = fp1.getContainer();
        container.clear();
        fp1.readCSV(path1);
        Item apple = new Item(5510,"Production",515,"Apples");
        Item bananas = new Item(5510,"Production",486,"Bananas");
        Area portugal = new Area("QCL","Crops and livestock products",174,"Portugal");
        Area spain = new Area("QCL","Crops and livestock products",203,"Spain");
        Map<Integer, List<String>> expected = new HashMap<>();
        ArrayList<String> arrayListExpected=new ArrayList<>();
        arrayListExpected.add("Portugal");
        arrayListExpected.add("Spain");
        expected.put(2,arrayListExpected);
        Map<Integer, List<String>> result = maxConsecutivePositiveIncreaseYears.countriesWithMaxConsecutivePositiveIncreaseYearsOfFruitF(apple,container);

        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(expected,result);

        expected.clear();
        result.clear();
        arrayListExpected.clear();
        Assert.assertTrue(result.isEmpty());

        arrayListExpected.add("Portugal");
        arrayListExpected.add("Spain");
        expected.put(4,arrayListExpected);
        result= maxConsecutivePositiveIncreaseYears.countriesWithMaxConsecutivePositiveIncreaseYearsOfFruitF(bananas,container);
        Assert.assertFalse(result.isEmpty());
        Assert.assertEquals(expected,result);

    }

    public void testGetSequence() throws FileNotFoundException {
        fp1 = new FileIO();
        ArrayList<FruitProduction> container = fp1.getContainer();
        container.clear();
        fp1.readCSV(path1);
        Item apple = new Item(5510,"Production",515,"Apples");
        Item bananas = new Item(5510,"Production",486,"Bananas");
        Area portugal = new Area("QCL","Crops and livestock products",174,"Portugal");
        Area spain = new Area("QCL","Crops and livestock products",203,"Spain");

        int expected = 2;
        int result = maxConsecutivePositiveIncreaseYears.getSequence(portugal,apple,container);
        Assert.assertEquals(expected, result);

        expected=4;
        result= maxConsecutivePositiveIncreaseYears.getSequence(portugal,bananas,container);
        Assert.assertEquals(expected, result);

        expected=2;
        result= maxConsecutivePositiveIncreaseYears.getSequence(spain,apple,container);
        Assert.assertEquals(expected, result);

        expected=4;
        result= maxConsecutivePositiveIncreaseYears.getSequence(spain,bananas,container);
        Assert.assertEquals(expected, result);

        fp2 = new FileIO();
        container = fp2.getContainer();
        container.clear();
        fp2.readCSV(path2);
        Area czechoslovakia = new Area("QCL","Crops and livestock products",51,"Czechoslovakia");
        Area korea= new Area("QCL","Crops and livestock products",116,"Democratic People's Republic of Korea");

        expected=3;
        result= maxConsecutivePositiveIncreaseYears.getSequence(czechoslovakia,apple,container);
        Assert.assertEquals(expected, result);

        expected=22;
        result= maxConsecutivePositiveIncreaseYears.getSequence(korea,apple,container);
        Assert.assertEquals(expected, result);




    }


}