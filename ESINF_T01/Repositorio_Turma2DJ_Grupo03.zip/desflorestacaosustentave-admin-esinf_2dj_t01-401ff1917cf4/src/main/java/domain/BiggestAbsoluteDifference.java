package domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class BiggestAbsoluteDifference {

    public BiggestAbsoluteDifference(){}

    /**Given a certain country (Area), it searches the cointainer with all the information about the fruit production and finds
     * the pair of years and the fruit of which the difference of production was the biggest. First, it stores the all the fruits
     * that were produced by the given country in a TreeSet, by calling the method getFruitList. Then, it goes through this TreeSet
     * and, for each fruit, gets the information of the production of the fruit, by calling the method getListAreaFruit, and stores
     * it in a ArrayList. Then it takes this ArrayList and will use it to calculate the biggest absolute difference, calling the method
     * getBiggestDiff and stores the results in the Map. Finally, it will compare all the results of at the Map to discover which one is
     * the biggest absolute difference out of all fruits.
     *
     * @param area a certain country information
     * @param  container the list containing all FruitProduction objects
     * @return a string with the par of years, the fruit and the biggest absolute difference of production*/
    public static String pairOfYearFruitAndHighestAbsolutValue(Area area, ArrayList<FruitProduction> container){
        Map<String,Map<Long,String>> map = new HashMap<>();
        TreeSet<String> fruitsOfCountry = getFruitList(area, container);

        for (String fruitName : fruitsOfCountry){
            ArrayList<FruitProduction> areaFruitList = getListAreaFruit(fruitName,area,container);
            Map<Long,String> diffAndYearsMap= getBiggestDiff(areaFruitList);
            map.put(fruitName,diffAndYearsMap);
        }

        Long maxValue = 0L;
        int index = 0;
        String output = "";
        Object[] listFruits = map.keySet().toArray();


        for (Map map1 : map.values()){
            if (Long.parseLong(map1.keySet().toString().replaceAll("[()\\[\\]]", "")) >= maxValue){
                maxValue = Long.parseLong(map1.keySet().toString().replaceAll("[()\\[\\]]", ""));
                output = String.format("[%s,%s,%d]",map1.get(maxValue),listFruits[index],maxValue);
            }
            index++;
        }

        return output;
    }

    /**This method goes through the container and searches for all the fruits that were produced by the given country (area)
     *
     * @param area a certain country information
     * @param container the list containing all FruitProduction objects
     * @return a TreeSet with all the fruits of the given country*/
    public static TreeSet<String> getFruitList(Area area, ArrayList<FruitProduction> container){
        TreeSet<String> fruits = new TreeSet<>();

        for (FruitProduction fp : container){
            if(area.area.equals(fp.area.area)){
                fruits.add(fp.fruit.item);
            }
        }
        return fruits;
    }

    /**This method goes through the container and gets all the information about the production of the given fruit in the given country (area).
     *
     * @param fruit the name of the wanted fruit
     * @param area a certain country information
     * @param container the list containing all FruitProduction objects
     * @return an ArrayList with the information of a*/
    public static ArrayList<FruitProduction> getListAreaFruit(String fruit, Area area, ArrayList<FruitProduction> container){
        ArrayList<FruitProduction> areaFruitList = new ArrayList<>();

        for (FruitProduction fp : container){
            if((fp.area.area.equals(area.area) && (fp.fruit.item.equals(fruit)))){
                areaFruitList.add(fp);
            }
        }
        return areaFruitList;
    }

    /**This method goes through the list, and calculates the biggest difference in the production between all years.
     * It takes two years at a time, calculates their difference and stores the value so that it can be compared in the next
     * calculation of the difference. Every time that appeares a difference bigger than the one stored, it updates the value of the
     * variable diff.
     *
     * @param areaFruitList list with all the information about the production of a certain fruit in a certain country
     * @return a map with the biggest absolute difference of production of a certain fruit and the pair of years*/
    public static Map<Long,String> getBiggestDiff(ArrayList<FruitProduction> areaFruitList){
        Map<Long,String> map = new HashMap<>();
        Long diff = 0L;
        String year = "";

        for (int i = 0; i < areaFruitList.size()-1; i++) {
            for (int j = i+1; j < areaFruitList.size(); j++) {
                if(Math.abs(areaFruitList.get(i).value.value - areaFruitList.get(j).value.value) > diff){
                    diff = Math.abs(areaFruitList.get(i).value.value - areaFruitList.get(j).value.value);
                    year = areaFruitList.get(i).year.year + "/" + areaFruitList.get(j).year.year;
                }
            }
        }

        map.put(diff,year);
        return map;
    }

}