package domain;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class Year {

    public Integer yearCode;

    public Integer year;

    public Year(Integer yearCode, Integer year) {
        this.yearCode = yearCode;
        this.year = year;
    }

    public Integer getYearCode() {
        return yearCode;
    }

    public Integer getYear() {
        return year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Year)) return false;

        Year year1 = (Year) o;

        if (!getYearCode().equals(year1.getYearCode())) return false;
        return getYear().equals(year1.getYear());
    }

    @Override
    public String toString() {
        return yearCode +","+ year;
    }
}
