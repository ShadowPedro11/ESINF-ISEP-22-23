package domain;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class Area {

    public String domainCode;

    public String domain;

    public Integer areaCode;

    public String area;

    public Area(String domainCode, String domain, Integer areaCode, String area) {
        this.domainCode = domainCode;
        this.domain = domain;
        this.areaCode = areaCode;
        this.area = area;
    }

    public String getDomainCode() {
        return domainCode;
    }

    public String getDomain() {
        return domain;
    }

    public Integer getAreaCode() {
        return areaCode;
    }

    public String getArea() {
        return area;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Area)) return false;

        Area area1 = (Area) o;

        if (!getDomainCode().equals(area1.getDomainCode())) return false;
        if (!getDomain().equals(area1.getDomain())) return false;
        if (!getAreaCode().equals(area1.getAreaCode())) return false;
        return getArea().equals(area1.getArea());
    }

    @Override
    public String toString() {
        return domainCode +","+ domain +","+ areaCode +","+ area;
    }
}
