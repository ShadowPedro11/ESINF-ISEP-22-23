package domain;

import java.util.Comparator;

/**
 *
 */
public class FruitProductionComparator implements Comparator<FruitProduction> {
    @Override
    public int compare(FruitProduction o1, FruitProduction o2) {
        if (o1.getYear().getYear() == o2.getYear().getYear()) {
            if (o1.getValue().getValue() == o2.getValue().getValue()) {
                return 0;
            } else if (o1.getValue().getValue() < o2.getValue().getValue()) {
                return 1;
            } else {
                return -1;
            }
        } else if (o1.getYear().getYear() > o2.getYear().getYear()) {
            return 1;
        } else {
            return -1;
        }
    }
}
