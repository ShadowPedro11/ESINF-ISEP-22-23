package domain;

import java.util.*;

public class MinimumCountries {

    /**
     * Given a "q" production quantity, this method will discover the minimum amount of countries, that, together,
     * can produce more than "q".
     * @param quantity is the minimum production quantity that the group of countries must have.
     * @return the minimum necessary countries to produce more than "q" (return 0 if all the countries registered
     * from the .csv can't reach the "q" production, and return -1 if "q" is <= 0 or there is no information to search).
     */
    public Integer smallestNumberOfCountriesToProduceMoreThanQ(Value quantity, Map<String, ArrayList<Long>> countriesNProductions){

        final int NO_COUNTRIES = 0;

        Long value = quantity.getValue();

        if(value <= 0 || countriesNProductions.isEmpty())
            return -1;


        List<Long> countries = new LinkedList<>();

        for(ArrayList<Long> al : countriesNProductions.values()){
            Long sum=0L;
            for(Long i : al){
                sum += i;
            }
            countries.add(sum);
        }

        countries.sort(Collections.reverseOrder());

        long sum = 0;
        int count = 0;

        int numberOfCountries = countries.size()-1;

        while(sum < value && count <= numberOfCountries) sum += countries.get(count++);

        return (sum < value) ? NO_COUNTRIES : count;
    }
}
