package domain;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class Value {

    public String unit;

    public Long value;

    public Value(String unit, Long value) {
        this.unit = unit;
        this.value = value;
    }

    public String getUnit() {
        return unit;
    }

    public Long getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Value)) return false;

        Value value1 = (Value) o;

        if (!getUnit().equals(value1.getUnit())) return false;
        return getValue().equals(value1.getValue());
    }


    @Override
    public String toString() {
        return unit +","+ value;
    }
}
