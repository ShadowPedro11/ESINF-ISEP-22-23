package domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MaxConsecutivePositiveIncreaseYears {


    public MaxConsecutivePositiveIncreaseYears(){
    }

    /**
     * It checks if that item is already on the map, else it gets for all countries the most consecutive positive increase year for the given fruit.
     * @param f is used as the item chosen, so the fruit.
     * @param container gets the file with all the data.
     * @return gives back the updated map with the chosen item, in case it was not already there.
     */
    public Map<Integer, List<String>> countriesWithMaxConsecutivePositiveIncreaseYearsOfFruitF(Item f,ArrayList<FruitProduction> container){
        Map<String,Integer> map = new HashMap<>();
        for (FruitProduction fp : container) {
            if(fp.fruit.item.equals(f.item)){
                if(map.get(fp.area.area)== null){
                    map.put(fp.area.area, getSequence(fp.area,f,container));
                }
            }
        }
        Map<Integer, List<String>> agroupedContriesMap = groupCountries(map);

        return agroupedContriesMap;
    }

    /**
     * Organizes the information of the Map<String,Integer> to Map<Integer, List<String>>, basically group the
     * information, for each value of Max Consecutive increase we will have a list of countries whit have this value
     * @param map is the map with the values for each county
     * @return gives back the updated map with the chosen item, in case it was not already there.
     */

    public Map<Integer, List<String>> groupCountries(Map<String,Integer> map){
        Map<Integer, List<String>>agroupedList = new HashMap<Integer, List<String>>();

        for (Map.Entry<String,Integer> m : map.entrySet()){

            if(agroupedList.get(m.getValue())==null){
                List<String> contryList = new ArrayList<>();
                agroupedList.put(m.getValue(),contryList);
            }
            agroupedList.get(m.getValue()).add(m.getKey());
        }
        return agroupedList;
    }



    /**
     * For a certain Area and Item, it gets the sequence of most consecutive positive increase year for a country.
     * @param a is used as the area chosen, so the country.
     * @param f is used as the item chosen, so the fruit.
     * @param container gets the file with all the data.
     * @return gives back the max number reached by the country and the fruit.
     */
    public Integer getSequence(Area a,Item f,ArrayList<FruitProduction> container){
        Integer count=0;
        Integer save =-1;
        for (int i = 0; i < container.size(); i++) {
            if(container.get(i).area.area.equals(a.area)){
                if(container.get(i).fruit.item.equals(f.item)){
                    while ((container.get(i).area.area.equals(a.area))&&(container.get(i).fruit.item.equals(f.item))&&(container.get(i).value.value<(container.get(i+1).value.value))){
                        count++;
                        i++;
                        if(i==container.size()-1){
                            break;
                        }
                    }
                }
            }
            if(count>save){
                save=count;
            }
            count=0;
        }
        return save;
    }
}