package domain;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
/**
 * @author : Ricardo Venâncio - 1210828
 * @author : Pedro Pereira - 1211131
 **/
public class FileIO {

    ArrayList<FruitProduction> container = new ArrayList<>();

    public Map<String, ArrayList<Long>> countriesNProductions = new HashMap<>();

    public FileIO(String path) throws FileNotFoundException {
        readCSV(path);
    }

    public FileIO() {
    }

    public ArrayList<FruitProduction> getContainer() {
        return container;
    }

    /**
     * Loads the CSV data to a data structure.
     * @param path is the path to the .csv file to extract data.
     * @throws FileNotFoundException when there isn't any
     */
    public boolean readCSV(String path) throws FileNotFoundException {

        if(path == null)
            return false;

        File f = new File(path);

        if(!f.exists())
            return false;

        Scanner sc = new Scanner(f);

        // Reads the file headr (no data!).
        sc.nextLine();

        while(sc.hasNext()){

            // Variable line will contain data from the .csv each iteration. Fields will be the splitter.
            String line = sc.nextLine();
            String[] fields;

            // There isn't only one type of .csv documents, in other words, data is separated by commas, sometimes
            // have quotation marks, null fields and a field with a comma to maintain.
            // So, checking if the line contains a quotation mark, will make the regular expression
            // (to split) a bit different.
            if(line.contains("\""))
                fields = line.split("\"?,\"");
            else
                fields = line.split(",");

            // Initialization of the String fields using the "fields" String array
            final String DOMAIN_CODE = fields[0].replaceAll("\"", ""),
                    DOMAIN = fields[1].replaceAll("\"", ""),
                    AREA = fields[3].replaceAll("\"", ""),
                    ELEMENT = fields[5].replaceAll("\"", ""),
                    ITEM = fields[7].replaceAll("\"", ""),
                    UNIT = fields[10].replaceAll("\"", ""),
                    FLAG = fields[12].replaceAll("\"", ""),
                    FLAG_DESCRIPTION = fields[13].replaceAll("\"", "");
            // Check if the field 11 (respective to Value) is blank, if it is fill with 0
            if(fields[11].isBlank())
                fields[11] = "0";

            // Initialization of the Integer fields using the "fields" String array
            // Its necessary to pass String values to Integers using the function Integer.parseInt()
            final Integer AREA_CODE = Integer.parseInt(fields[2]),
                    ELEMENT_CODE = Integer.parseInt(fields[4]),
                    ITEM_CODE = Integer.parseInt(fields[6]),
                    YEAR_CODE = Integer.parseInt(fields[8]),
                    YEAR = Integer.parseInt(fields[9]);

            final Long VALUE = Long.parseLong(fields[11]);

            // Initialization of the objects Area,Item, Year and Value using the elements initialized before
            Area a = new Area(DOMAIN_CODE, DOMAIN, AREA_CODE, AREA);
            Item i = new Item(ELEMENT_CODE, ELEMENT, ITEM_CODE, ITEM);
            Year y = new Year(YEAR_CODE, YEAR);
            Value v = new Value(UNIT, VALUE);

            // Initialization of the object Fruit Production compound by the Objects initialized before
            FruitProduction fp = new FruitProduction(a, i, y, v, FLAG, FLAG_DESCRIPTION);

            // Countries and productions map.
            if(countriesNProductions.get(AREA) == null) {
                ArrayList<Long> quantities = new ArrayList<>();
                countriesNProductions.put(AREA, quantities);
            }
            countriesNProductions.get(AREA).add(VALUE);


            // Adding the Fruit Production object to a container (ArrayList of FruitProductions)
            container.add(fp);
        }
        sc.close();
        return true;
    }
}
