package domain;

import java.util.*;

public class CountriesListed {

    /**
     * This method will return a sorted LinkedList of FruitProduction with the countries with at least a year of production of the F fruit
     * and a productionQuantity equals or bigger than @productionQuantity
     * @param container the list containing all FruitProduction objects
     * @param fruit the fruit that we want to look for
     * @param countryNames Set of Strings containing the name of the countries
     * @param productionQuantity the minimum productionQuantity accepted
     * @return the sorted list
     */
    public static LinkedList<FruitProduction> countriesListLowestYear(ArrayList<FruitProduction> container,Set<String> countryNames, Item fruit, long productionQuantity) {
        if (container == null || fruit == null || countryNames == null) return null;
        LinkedList<FruitProduction> countriesList = new LinkedList<>();

        TreeSet<FruitProduction> fruitProductionsOfAItemPerCountry;
        FruitProduction aux;

        for (String countryName : countryNames) {
            fruitProductionsOfAItemPerCountry = fruitProductionsPerCountryOfFruitF(container, fruit, countryName);
            aux = lowestYearWithProductionQ(fruitProductionsOfAItemPerCountry, productionQuantity);

            if (aux == null) {
                fruitProductionsOfAItemPerCountry.clear();
                continue;
            }

            countriesList.add(aux);
            fruitProductionsOfAItemPerCountry.clear();
        }

        countriesList.sort(new FruitProductionComparator());
        return countriesList;
    }

    /**
     * This method returns the FruitProduction with at least a year of production and with the minimum quantity of the desired fruit
     * @param fruitProductionsOfAItemPerCountry a sorted TreeSet of FruitProduction, obtained with the productionsPerCountry method
     * @param productionQuantity the minimum quantity accepted
     * @return the desired FruitProduction object, if any of the FruitProduction meets the requirements it will return null
     */
    public static FruitProduction lowestYearWithProductionQ(TreeSet<FruitProduction> fruitProductionsOfAItemPerCountry, long productionQuantity) {
        if (fruitProductionsOfAItemPerCountry == null) return null;
        int yearsProducing = 0;
        for (FruitProduction production : fruitProductionsOfAItemPerCountry) {
            if ((yearsProducing >= 1) && (production.getValue().getValue() >= productionQuantity)) {
                return production;
            }
            yearsProducing++;
        }
        return null;
    }

    /**
     * This method returns a TreeSet of FruitProduction containing all the FruitProduction objects of a certain fruit and country
     * this list will be sorted by year
     * @param container the list containing all FruitProduction objects
     * @param fruit the fruit that we want the FruitProductions to be returned associated
     * @param countryName the name of the country that we want associated with the FruitProduction to be returned
     * @return a sorted TreeSet containing all the FruitProduction objects with the wanted country and fruit
     */
    public static TreeSet<FruitProduction> fruitProductionsPerCountryOfFruitF(ArrayList<FruitProduction> container, Item fruit, String countryName) {
        if (container == null || fruit == null || countryName == null) return null;
        TreeSet<FruitProduction> countryList = new TreeSet<>(new FruitProductionComparator());
        for (FruitProduction production : container) {
            if (production.getFruit().getItemCode().equals(fruit.getItemCode()) && production.getArea().getArea().equals(countryName)) {
                countryList.add(production);
            }
        }
        return countryList;
    }

}
