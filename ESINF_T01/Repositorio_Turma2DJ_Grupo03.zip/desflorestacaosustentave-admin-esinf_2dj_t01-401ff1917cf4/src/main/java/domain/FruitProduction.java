package domain;

import java.util.ArrayList;

/**
 * Manages production related to types of fruit, in several countries, along the years.
 **/
public class FruitProduction implements Comparable<FruitProduction> {

    /**
     * Country.
     */
    public Area area;

    /**
     * Fruit.
     */
    public Item fruit;

    /**
     * Production's year.
     */
    public Year year;

    /**
     * Production's quantity, in tons.
     */
    public Value value;

    /**
     * Flag.
     */
    public String flag;

    /**
     * Flag description.
     */
    public String flagDescription;


    public FruitProduction(Area area, Item fruit, Year year, Value value, String flag, String flagDescription) {
        this.area = area;
        this.fruit = fruit;
        this.year = year;
        this.value = value;
        this.flag = flag;
        this.flagDescription = flagDescription;
    }

    public Item getFruit() {
        return fruit;
    }

    public Area getArea() {
        return area;
    }

    public Year getYear() {
        return year;
    }

    public Value getValue() {
        return value;
    }
    
    public String getFlag() {
        return flag;
    }

    public String getFlagDescription() {
        return flagDescription;
    }

    public String toString() {
        return  area.toString() + ","+ fruit.toString() +"," + year.toString() +","+ value.toString() +","+ flag +","+ flagDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FruitProduction)) return false;

        FruitProduction that = (FruitProduction) o;

        if (!getArea().equals(that.getArea())) return false;
        if (!getFruit().equals(that.getFruit())) return false;
        if (!getYear().equals(that.getYear())) return false;
        if (!getValue().equals(that.getValue())) return false;
        if (!getFlag().equals(that.getFlag())) return false;
        return getFlagDescription().equals(that.getFlagDescription());
    }


    @Override
    public int compareTo(FruitProduction o) {
        if (this.getValue().getValue() == o.getValue().getValue()) {
            return 0;
        } else if (this.getValue().getValue() < o.getValue().getValue()) {
            return 1;
        } else {
            return -1;
        }
    }
}
