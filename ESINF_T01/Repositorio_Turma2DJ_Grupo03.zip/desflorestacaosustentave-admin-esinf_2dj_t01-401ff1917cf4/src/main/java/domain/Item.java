package domain;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class Item {

    public Integer elementCode;

    public String element;

    public Integer itemCode;

    public String item;

    public Item(Integer elementCode, String element, Integer itemCode, String item) {
        this.elementCode = elementCode;
        this.element = element;
        this.itemCode = itemCode;
        this.item = item;
    }

    public Integer getElementCode() {
        return elementCode;
    }

    public String getElement() {
        return element;
    }

    public Integer getItemCode() {
        return itemCode;
    }

    public String getItem() {
        return item;
    }

    @Override
    public String toString() {
        return elementCode + "," + element + "," + itemCode + "," + item;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof Item)
            if (this.getItem().equals(((Item) obj).getItem()))
                return true;
        /*
        if (this == obj) {
            return true;
        }

        if (obj instanceof Item)
            if (this.getItem() == ((Item) obj).getItem())
                if (this.getItemCode() == ((Item) obj).getItemCode())
                    if (this.getElement() == ((Item) obj).getElement())
                        if (this.getElementCode() == ((Item) obj).getElementCode())
                            return true;
         */
        return false;
    }

}