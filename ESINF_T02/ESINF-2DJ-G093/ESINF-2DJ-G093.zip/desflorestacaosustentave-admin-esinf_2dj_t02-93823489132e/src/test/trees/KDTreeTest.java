package trees;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import tree.KDTree;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class KDTreeTest {

    Point2D[] coords = {
            new Point2D.Double(40f, 45f),
            new Point2D.Double(15f, 70f),
            new Point2D.Double(70f, 10f),
            new Point2D.Double(69f, 50f),
            new Point2D.Double(66f, 85f),
            new Point2D.Double(85f, 90f)
    };

    Character[] representation = {'A', 'B', 'C', 'D', 'E', 'F'};

    KDTree<Character> instance;

    Point2D.Double[] coords2 = {
            new Point2D.Double(3f, 9f),
            new Point2D.Double(1f, 7f),
            new Point2D.Double(7f, 9f),
            new Point2D.Double(2f, 1f),
            new Point2D.Double(1f, 4f),
            new Point2D.Double(5f, 9f),
            new Point2D.Double(9f, 6f),
            new Point2D.Double(11f, 6f),
            new Point2D.Double(7f, 3f),
            new Point2D.Double(6f, 1f),
            new Point2D.Double(8f, 2f)
    };

    Integer[] representation2 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

    KDTree<Integer> instance2;

    @Before
    public void setUp(){

        instance = new KDTree<>();

        for(int i=0;i<coords.length;i++){
            instance.insert(representation[i], (Point2D.Double) coords[i]);
        }

        instance2 = new KDTree<>();
        for(int i=0;i<coords2.length;i++){
            instance2.insert(representation2[i], coords2[i]);
        }
    }

    @Test
    public void findTest(){

        System.out.println("exact find");

        // Best case
        Point2D.Double coordinate = new Point2D.Double(40, 45);
        Character result = instance.find(coordinate);
        Character expected = 'A';
        Assert.assertEquals(expected, result);

        // Average Case
        coordinate = new Point2D.Double(66, 85);
        result = instance.find(coordinate);
        expected = 'E';
        Assert.assertEquals(expected, result);

        // Worst case
        coordinate = new Point2D.Double(85, 91);
        result = instance.find(coordinate);
        expected = null;
        Assert.assertEquals(expected, result);

        ////////////////////////////////////////////

        coordinate = new Point2D.Double(3, 9);
        Integer element = instance2.find(coordinate);
        Integer exp = 1;
        Assert.assertEquals(exp, element);

        coordinate = new Point2D.Double(7 ,3);
        element = instance2.find(coordinate);
        exp = 9;
        Assert.assertEquals(exp, element);

        coordinate = new Point2D.Double(8, 3);
        element = instance2.find(coordinate);
        exp = null;
        Assert.assertEquals(exp, element);


    }

    @Test
    public void nearestNeighbourTest(){

        System.out.println("nearest neighbour");

        // Best case
        Point2D.Double coordinate = new Point2D.Double(40, 45);
        Character result = instance.nearestNeighbour(coordinate);
        Character expected = 'A';
        Assert.assertEquals(expected, result);

        // Average Case
        coordinate = new Point2D.Double(74, 70);
        result = instance.nearestNeighbour(coordinate);
        expected = 'E';
        Assert.assertEquals(expected, result);

        // Worst case
        coordinate = new Point2D.Double(91, 91);
        result = instance.nearestNeighbour(coordinate);
        expected = 'F';
        Assert.assertEquals(expected, result);

        ////////////////////////////////////////////

        coordinate = new Point2D.Double(4, 7);
        Integer r = instance2.nearestNeighbour(coordinate);
        Integer exp = 1;
        Assert.assertEquals(exp, r);


        coordinate = new Point2D.Double(4, 5);
        r = instance2.nearestNeighbour(coordinate);
        exp = 5;
        Assert.assertEquals(exp, r);

    }

    @Test
    public void regionSearchTest(){

        System.out.println("region search");

        Point2D.Double p1 = new Point2D.Double(60, 90);
        Point2D.Double p2 = new Point2D.Double(80, 60);

        List<Character> result = instance.regionSearch(p1, p2);
        List<Character> expected = new ArrayList<>();
        expected.add('E');
        Assert.assertEquals(expected, result);


        p1 = new Point2D.Double(10, 100);
        p2 = new Point2D.Double(85, 10);

        result = instance.regionSearch(p1, p2);
        expected = new ArrayList<>();
        expected.add('A');
        expected.add('B');
        expected.add('D');
        expected.add('E');
        Assert.assertEquals(expected, result);

        p1 = new Point2D.Double(2, 11);
        p2 = new Point2D.Double(9, 2);
        List<Integer> result2 = instance2.regionSearch(p1, p2);
        List<Integer> expected2 = new ArrayList<>();
        expected2.add(1);
        expected2.add(3);
        expected2.add(9);
        expected2.add(6);
        Assert.assertEquals(expected2, result2);

    }



}

