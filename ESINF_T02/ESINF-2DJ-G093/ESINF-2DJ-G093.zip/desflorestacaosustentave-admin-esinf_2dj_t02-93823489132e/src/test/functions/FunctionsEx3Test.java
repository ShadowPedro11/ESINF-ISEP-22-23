package functions;

import domain.Area;
import domain.Element;
import domain.Item;
import domain.Value;
import io.DataSheet;
import model.AreaValue;
import model.*;
import org.junit.Assert;
import org.junit.Test;
import tree.BST;

import java.util.ArrayList;
import java.util.List;

public class FunctionsEx3Test {
    private final String TEST_PATH_SMALL = "src/resources/TestFileEX3.csv";
    private final String TEST_PATH_MEDIUM = "src/resources/Production_Crops_Livestock_EU_shuffle_medium.csv";
    private final String TEST_PATH_BIG = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";
    Item item1 = new Item(426,"'01251","Carrots and turnips");
    Item item2 = new Item(1091,"'0232","Eggs from other birds in shell, fresh, n.e.c.");
    Element element1 = new Element(5419, "Yield");
    Element element2 = new Element(5413,"Yield");
    DataSheet d1 = new DataSheet();


    @Test
    public void testGetTopNAreasNullParam() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        List<AreaValue> actual = f.getTopNAreas(null, null, null);
        Assert.assertEquals(expected, actual);
    }
    @Test
    public void testGetTopNAreasNullItem() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        List<AreaValue> actual = f.getTopNAreas(null, element1, 3);
        Assert.assertEquals(expected, actual);
    }
    @Test
    public void testGetTopNAreasNullElement() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        List<AreaValue> actual = f.getTopNAreas(item1, null, 3);
        Assert.assertEquals(expected, actual);
    }
    @Test
    public void testGetTopNAreasNullN() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        List<AreaValue> actual = f.getTopNAreas(item1, element1, null);
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void testGetTopNAreasSmallFile() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = new ArrayList<>();
        AreaValue av1 = new AreaValue(new Area(97,348,"Hungary"), new Value(300000.000000,"hg/ha","E"));
        AreaValue av2 = new AreaValue(new Area(203,724,"Spain"), new Value(290000.000000,"hg/ha","E"));
        AreaValue av3 = new AreaValue(new Area(198,705,"Slovenia"), new Value(215155.000000,"hg/ha","E"));

        expected.add(av1);
        expected.add(av2);
        expected.add(av3);
        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item1, element1, n);
        Assert.assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void testGetTopNAreasLessThanN() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = new ArrayList<>();
        AreaValue av1 = new AreaValue(new Area(27,100,"Bulgaria"), new Value(35.000000,"No/An","E"));

        expected.add(av1);

        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item2, element2, n);
        Assert.assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void testGetTopNAreasMediumFile() {
        d1.parseBaseDataCSV(TEST_PATH_MEDIUM);
        Functions f = new Functions(d1);
        List<AreaValue> expected = new ArrayList<>();
        AreaValue av1 = new AreaValue(new Area(27, 100, "Bulgaria"), new Value(192.000000, "No/An", "E"));

        expected.add(av1);

        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item2, element2, n);
        Assert.assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void testGetTopNAreasBigFile() {
        d1.parseBaseDataCSV(TEST_PATH_BIG);
        Functions f = new Functions(d1);
        List<AreaValue> expected = new ArrayList<>();
        AreaValue av1 = new AreaValue(new Area(27, 100, "Lithuania"), new Value(5.000000, "No/An", "E"));
        AreaValue av2 = new AreaValue(new Area(27, 100, "Spain"), new Value(1189.000000, "No/An", "E"));
        AreaValue av3 = new AreaValue(new Area(27, 100, "Bulgaria"), new Value(192.000000, "No/An", "E"));

        expected.add(av1);
        expected.add(av2);
        expected.add(av3);

        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item2, element2, n);
        Assert.assertEquals(expected.toString(), actual.toString());
    }

    @Test
    public void testAddToAreaValuePerItemElementBST() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);

        Item carrots = new Item(426,"'01251","Carrots and turnips");
        Item chillies = new Item(401,"'01231","Chillies and peppers, green (Capsicum spp. and Pimenta spp.)");
        Item cantaloupes = new Item(568,"'01229","Cantaloupes and other melons");
        Item potatoes = new Item(116,"'01510","Potatoes");

        Element yield = new Element(5419,"Yield");
        Element productions = new Element(5510,"Production");

        ItemsElements carrotsYield = new ItemsElements(carrots,yield);
        ItemsElements chilliesYield = new ItemsElements(chillies,yield);
        ItemsElements cantaloupesYield = new ItemsElements(cantaloupes,yield);
        ItemsElements potatoesProductions = new ItemsElements(potatoes,productions);
        ItemsElements chilliesProductions = new ItemsElements(chillies,productions);
        ItemsElements cantaloupesProductions = new ItemsElements(cantaloupes,productions);

        BST<AreaValuePerItemElement> actual = d1.getAreaValuePerItemElementBST();

        Assert.assertNull(actual.find(new AreaValuePerItemElement(potatoesProductions,null)));
        Assert.assertNull(actual.find(new AreaValuePerItemElement(chilliesProductions,null)));
        Assert.assertNull(actual.find(new AreaValuePerItemElement(cantaloupesProductions,null)));
        Assert.assertNotNull(actual.find(new AreaValuePerItemElement(carrotsYield,null)));
        Assert.assertNotNull(actual.find(new AreaValuePerItemElement(chilliesYield,null)));
        Assert.assertNotNull(actual.find(new AreaValuePerItemElement(cantaloupesYield,null)));
    }

    @Test
    public void testGetTopNAreasIvalidItem() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        Item item3 = new Item(123, "erw", "ola");
        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item3, element1, n);
        Assert.assertEquals(expected, actual);
    }
    @Test
    public void testGetTopNAreasInvalidElement() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        Element element3 = new Element(123, "erw");
        Integer n = 3;
        List<AreaValue> actual = f.getTopNAreas(item1, element3, n);
        Assert.assertEquals(expected, actual);
    }
    @Test
    public void testGetTopNAreasInvalidN() {
        d1.parseBaseDataCSV(TEST_PATH_SMALL);
        Functions f = new Functions(d1);
        List<AreaValue> expected = null;

        Integer n = -1;
        List<AreaValue> actual = f.getTopNAreas(item1, element1, n);
        Assert.assertEquals(expected, actual);
    }
}