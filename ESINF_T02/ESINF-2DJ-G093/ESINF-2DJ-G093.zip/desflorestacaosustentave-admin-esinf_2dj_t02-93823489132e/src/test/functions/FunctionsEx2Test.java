package functions;

import domain.Area;
import domain.Element;
import domain.Item;
import domain.Year;
import io.DataSheet;
import junit.framework.TestCase;
import model.AverageValuebyItemElementYearInterval;
import model.ItemsElementsAccumulatedValue;
import model.ItemsElementsPerArea;
import org.junit.Assert;
import org.junit.Test;
import tree.AVL;
import tree.BST;
import tree.Utils;

import java.util.ArrayList;
import java.util.List;

public class FunctionsEx2Test extends TestCase {

    private final String TEST_PATH = "src/resources/TestFileEX2.csv";
    private final String TEST_PATH_2 = "src/resources/TestFileDataSheetEX2.csv";
    private final String EU_SMALL_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_small.csv";
    private final String EU_MEDIUM_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_medium.csv";
    private final String EU_LARGE_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";

    Area spain = new Area(203,724,"Spain");
    Area frança = new Area(68,250,"France");
    Area portugal = new Area(174,620,"Portugal");
    Area italy = new Area(106,380,"Italy");
    Area germany = new Area(79,276,"Germany");
    Item item1 = new Item(689,"'01652","Chillies and peppers, dry (Capsicum spp., Pimenta spp.), raw");
    Item item2 = new Item(1806,"'F1806","Beef and Buffalo Meat");
    Item item3 = new Item(549,"'01351.02","Gooseberries");
    Item item4 = new Item(677,"'01659","Hop cones");
    Item item5 = new Item(75,"'0117","Oats");
    Item item6 = new Item(526,"'01343","Apricots");
    Item item7 = new Item(1242,"'21700.02","Margarine and shortening");
    Item item8 = new Item(56,"'0112","Maize (corn)");
    Item item9 = new Item(27,"'0113","Rice");
    Item item10 = new Item(407,"'01254","Leeks and other alliaceous vegetables");
    Item item11 = new Item(423,"'01241.01","String beans");
    Item item12 = new Item(897,"'22211","Whole milk powder");
    Item item13 = new Item(394,"'01235","Pumpkins, squash and gourds");
    Item item14 = new Item(521,"'01342.01","Pears");
    Item item15 = new Item(260,"'01450","Olives");
    Item item16 = new Item(1062,"'0231","Hen eggs in shell, fresh");
    Item item17 = new Item(60,"'21691.02","Oil of maize");
    Item item18 = new Item(1807,"'F1807","Sheep and Goat Meat");
    Item item19 = new Item(898,"'22212","Skim milk and whey powder");
    Element element1 = new Element(5419,"Yield");
    Element element2 = new Element(5510,"Production");
    Element element3 = new Element(5312,"Area harvested");
    Element element4 = new Element(5313,"Laying");

    // Test method of year format
    @Test
    public void testFormatYear() {
        Functions EX = new Functions();
        String year = "[2000,2011]";
        List<Year> expected = new ArrayList<>();
        expected.add(new Year(2000,2000));
        expected.add(new Year(2011,2011));
        List<Year> actual = EX.formatYear(year);
        Assert.assertEquals(expected.toString(),actual.toString());
    }

    // Test sort method
    @Test
    public void testSort() {
        Item item = new Item(116,"'01510","Potatoes");
        Element element = new Element(5419,"Yield");
        Year year1 = new Year(2001,2001);
        Year year2 = new Year(2002,2002);
        Year year3 = new Year(2003,2003);
        Year year4 = new Year(2004,2004);
        Year year5 = new Year(2005,2005);
        Year year6 = new Year(2006,2006);
        AverageValuebyItemElementYearInterval obj1 = new AverageValuebyItemElementYearInterval(year1,year2,item,element,1.00);
        AverageValuebyItemElementYearInterval obj2 = new AverageValuebyItemElementYearInterval(year2,year3,item,element,2);
        AverageValuebyItemElementYearInterval obj3 = new AverageValuebyItemElementYearInterval(year3,year4,item,element,3);
        AverageValuebyItemElementYearInterval obj4 = new AverageValuebyItemElementYearInterval(year4,year5,item,element,4);
        AverageValuebyItemElementYearInterval obj5 = new AverageValuebyItemElementYearInterval(year5,year6,item,element,5);
        List<AverageValuebyItemElementYearInterval> expected =new ArrayList<>();
        expected.add(obj5);
        expected.add(obj4);
        expected.add(obj3);
        expected.add(obj2);
        expected.add(obj1);
        List<AverageValuebyItemElementYearInterval> actual = new ArrayList<>();
        actual.add(obj5);
        actual.add(obj4);
        actual.add(obj3);
        actual.add(obj2);
        actual.add(obj1);
        Utils.mergeSort(actual);
        System.out.println("Sort Test:");
        System.out.println("Actual");
        for (AverageValuebyItemElementYearInterval c : actual){
            System.out.print(c);
        }
        System.out.println("Expected");
        for (AverageValuebyItemElementYearInterval c : expected){
            System.out.print(c);
        }
        System.out.println("=============================================");
        Assert.assertEquals(expected,actual);
    }

    // Test return of a list expected
    @Test
    public void testFinalList() {
        List<AverageValuebyItemElementYearInterval> expected = new ArrayList<>();
        Year year1 = new Year(1990,1990);
        Year year2 = new Year(2000,2000);
        Element production = new Element(5510,"Production");
        Element stocks = new Element(5114,"Stocks");
        Element yield = new Element(5419,"Yield");
        Element areaHarvested = new Element(5312,"Area harvested");
        Item bees = new Item(1181,"'02196","Bees");
        Item potatoes = new Item(116,"'01510","Potatoes");
        Item oats = new Item(75,"'0117","Oats");
        Item sugar = new Item(1723,"'F1723","Sugar Crops Primary");
        Item poppy = new Item(296,"'01448","Poppy seed");
        Item mushrooms = new Item(449,"'01270","Mushrooms and truffles");
        Item whey = new Item(900,"'22130.02","Whey, dry");
        AverageValuebyItemElementYearInterval obj1 = new AverageValuebyItemElementYearInterval(year1,year2,bees,stocks,490183.000);
        AverageValuebyItemElementYearInterval obj2 = new AverageValuebyItemElementYearInterval(year1,year2,potatoes,production,150000.000);
        AverageValuebyItemElementYearInterval obj3 = new AverageValuebyItemElementYearInterval(year1,year2,potatoes,yield,84666.667);
        AverageValuebyItemElementYearInterval obj4 = new AverageValuebyItemElementYearInterval(year1,year2,oats,yield,42502.500);
        AverageValuebyItemElementYearInterval obj5 = new AverageValuebyItemElementYearInterval(year1,year2,sugar,areaHarvested,42035.000);
        AverageValuebyItemElementYearInterval obj6 = new AverageValuebyItemElementYearInterval(year1,year2,poppy,areaHarvested,1175.500);
        AverageValuebyItemElementYearInterval obj7 = new AverageValuebyItemElementYearInterval(year1,year2,mushrooms,production,0.000);
        AverageValuebyItemElementYearInterval obj8 = new AverageValuebyItemElementYearInterval(year1,year2,whey,production,0.000);
        expected.add(obj1);
        expected.add(obj2);
        expected.add(obj3);
        expected.add(obj4);
        expected.add(obj5);
        expected.add(obj6);
        expected.add(obj8);
        expected.add(obj7);
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH);
        Functions EX = new Functions(d1);
        Area area = new Area(11,040,"Austria");
        String years = "[1990,2000]";
        List<AverageValuebyItemElementYearInterval> actual = EX.getEx2(area,years);
        Assert.assertEquals(expected,actual);
        System.out.println("Ex2 Return Test:");
        System.out.println("Actual");
        for (AverageValuebyItemElementYearInterval c: actual){
            System.out.print(c);
        }
        System.out.println("Expected");
        for (AverageValuebyItemElementYearInterval c : expected){
            System.out.print(c);
        }
        System.out.println("=============================================");
    }

    // Test import for bst
    @Test
    public void testAddToItemsElementsPerAreaBST() {
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH_2);
        BST<ItemsElementsPerArea> actual = d1.getItemsElementsPerAreaBST();
        BST<ItemsElementsPerArea> expected = new AVL<>();

        expected.insert(new ItemsElementsPerArea(frança,new AVL<>()));
        expected.insert(new ItemsElementsPerArea(italy,new AVL<>()));
        expected.insert(new ItemsElementsPerArea(germany,new AVL<>()));
        expected.insert(new ItemsElementsPerArea(spain,new AVL<>()));
        expected.insert(new ItemsElementsPerArea(portugal,new AVL<>()));


        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item1,element1,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item2,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item3,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item4,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item5,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item6,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item7,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item8,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item9,element1,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item10,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item11,element1,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item12,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item13,element1,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item14,element1,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item15,element3,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item15,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(italy,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item16,element4,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item17,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item18,element2,new ArrayList<>()));
        expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item19,element2,new ArrayList<>()));

        ItemsElementsAccumulatedValue actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item1,element1,null));
        ItemsElementsAccumulatedValue expectedItemElement = expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item1,element1,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item2,element2,null));
        expectedItemElement = expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item2,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item3,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item3,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item4,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item4,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item5,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item5,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item6,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(spain,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item6,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item7,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item7,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item8,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item8,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item9,element1,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item9,element1,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item10,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item10,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item11,element1,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item11,element1,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item12,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(frança,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item12,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item13,element1,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item13,element1,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item14,element1,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item14,element1,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item15,element3,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item15,element3,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item15,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(portugal,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item15,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(italy,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item16,element4,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(italy,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item16,element4,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item17,element2,null));
        expectedItemElement = expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item17,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item18,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item18,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());

        actualItemElement = actual.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item19,element2,null));
        expectedItemElement =expected.find(new ItemsElementsPerArea(germany,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item19,element2,null));
        Assert.assertEquals(expectedItemElement.toString(),actualItemElement.toString());


        for (ItemsElementsPerArea c: actual.posOrder()){
            System.out.println(c);
        }
        System.out.println("=========================================================================");
        for (ItemsElementsPerArea c: expected.posOrder()){
            System.out.println(c);
        }

        Assert.assertNotNull(expected.find(new ItemsElementsPerArea(spain,null)));
        Assert.assertNotNull(expected.find(new ItemsElementsPerArea(frança,null)));
        Assert.assertNotNull(expected.find(new ItemsElementsPerArea(portugal,null)));
        Assert.assertNotNull(expected.find(new ItemsElementsPerArea(italy,null)));
        Assert.assertNotNull(expected.find(new ItemsElementsPerArea(germany,null)));

    }

    // Test find a null area
    @Test
    public void testfindItemsElementsPerAreaNull() {
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH_2);
        Area cyprus = new Area(50,196,"Cyprus");
        ItemsElementsPerArea actual = d1.findItemsElementsPerArea(cyprus);
        Assert.assertNull(actual);
    }

    // Test find a not null area
    @Test
    public void testfindItemsElementsPerAreaNotNull() {
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH_2);
        Area spain = new Area(203,724,"Spain");
        ItemsElementsPerArea actual = d1.findItemsElementsPerArea(spain);
        Assert.assertNotNull(actual);
    }

    // Test average method of null area
    @Test
    public void testAverageValuesByItemElementNotNull() {
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH);
        Functions functions = new Functions();
        Area austria = new Area(11,040,"Austria");
        Item potatoes = new Item(116,"'01510","Potatoes");
        Element yield = new Element(5419,"Yield");
        Year yearInitial = new Year(1990,1990);
        Year yearEnd = new Year(2000,2000);
        double expected = 84666.667;
        ItemsElementsAccumulatedValue itemsElementsAccumulatedValue = d1.getItemsElementsPerAreaBST().find(new ItemsElementsPerArea(austria,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(potatoes,yield,null));
        double actual = functions.getAverageValue(itemsElementsAccumulatedValue,yearInitial,yearEnd);
        Assert.assertEquals(String.format("%.3f",expected),String.format("%.3f",actual));

    }

    // Test average method of not null area
    @Test
    public void testAverageValuesByItemElementNull() {
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(TEST_PATH);
        Functions functions = new Functions();
        Area austria = new Area(11,040,"Austria");
        Item chillies = new Item(689,"'01652","Chillies and peppers, dry (Capsicum spp., Pimenta spp.), raw");
        Element yield = new Element(5419,"Yield");
        Year yearInitial = new Year(1990,1990);
        Year yearEnd = new Year(2000,2000);
        double expected = 0;
        ItemsElementsAccumulatedValue itemsElementsAccumulatedValue = d1.getItemsElementsPerAreaBST().find(new ItemsElementsPerArea(austria,null)).getItemsElementsBST().find(new ItemsElementsAccumulatedValue(chillies,yield,null));
        double actual = functions.getAverageValue(itemsElementsAccumulatedValue,yearInitial,yearEnd);
        Assert.assertEquals(String.format("%.3f",expected),String.format("%.3f",actual));


    }

    @Test
    public void testNull1() {
        Functions functions = new Functions();
        List<AverageValuebyItemElementYearInterval> expected = functions.getEx2(null, "[1999,2010]");
        Assert.assertNull(expected);
    }

    @Test
    public void testNull2() {
        Functions functions = new Functions();
        List<AverageValuebyItemElementYearInterval> expected = functions.getEx2(spain, "");
        Assert.assertNull(expected);
    }

    @Test
    public void testNull3() {
        Functions functions = new Functions();
        List<AverageValuebyItemElementYearInterval> expected = functions.getEx2(spain, null);
        Assert.assertNull(expected);
    }

    @Test
    public void testEuropeSmallFile(){
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(EU_SMALL_PATH);
        Functions functions = new Functions(d1);
        Area area = new Area(67,246,"Finland");
        String year = "[1996,2005]";
        for (AverageValuebyItemElementYearInterval c: functions.getEx2(area,year)){
            System.out.println(c);
        }
    }

    @Test
    public void testEuropeMediumFile(){
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(EU_MEDIUM_PATH);
        Functions functions = new Functions(d1);
        Area area = new Area(67,246,"Finland");
        String year = "[1996,2005]";
        for (AverageValuebyItemElementYearInterval c: functions.getEx2(area,year)){
            System.out.println(c);
        }
    }

    @Test
    public void testEuropeLargeFile(){
        DataSheet d1 = new DataSheet();
        d1.parseBaseDataCSV(EU_LARGE_PATH);
        Functions functions = new Functions(d1);
        Area area = new Area(67,246,"Finland");
        String year = "[1996,2005]";
        for (AverageValuebyItemElementYearInterval c: functions.getEx2(area,year)){
            System.out.println(c);
        }

    }

    /////////////////////////////////////////////////////////////////////////////////


}