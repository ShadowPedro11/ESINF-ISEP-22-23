package functions;

import domain.*;
import io.DataSheet;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

public class FunctionsEx4Test extends TestCase {

    private final String WW_SMALL_PATH = "src/resources/Production_Crops_Livestock_World_shuffle_small.csv";
    private final String MAIN_EU_SMALL_PATH = "src/resources/Production_Crops_Livestock_FR_GER_IT_PT_SP_shuffle_small.csv";
    private final String EU_SMALL_PATH= "src/resources/Production_Crops_Livestock_EU_shuffle_small.csv";
    private final String EU_MEDIUM_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_medium.csv";
    private final String EU_LARGE_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";
    private final String EU_SAMALL_PATH_AND_GEORGIA= "src/resources/TestFileEx4.csv";
    private final String A = "\"src/resources/AccumulatedValuesTest.csv\"";

    private DataSheet d1;
    private Functions f1;
    private DataSheet d2;
    private Functions f2;
    private DataSheet d3;
    private Functions f3;

    @Before
    public void setUp(){
        d1 = new DataSheet();
        d1.parseBaseDataCSV(EU_SMALL_PATH);
        f1 = new Functions(d1);
        d2 = new DataSheet();
        d2.parseBaseDataCSV(EU_MEDIUM_PATH);
        f2 = new Functions(d2);
        d3 = new DataSheet();
        d3.parseBaseDataCSV(EU_LARGE_PATH);
        f3 = new Functions(d3);
        //d1.parseAreaLocations();
        //areaDetailsBST= d1.getAreaDetailsBST();
    }



//    @Test
//    public void testAddToAreaDetailsBST(){
//
//        Year year = new Year(1990,1990);
//        Element production = new Element(5510,"Production");
//        Item potatoes = new Item(116,"'01510","Potatoes");
//        Area portugal = new Area(174,620,"Portugal");
//
//        AreaDetails newAreaDetails = new AreaDetails(portugal,potatoes,production,year);
//
//        assertEquals(true,d1.addToAreaDetailsBST(newAreaDetails));
//
//    }

    @Test
    public void testSucessGetCloseAreaDetails(){

        AreaCoordinates closeToPortugalCoordinates= new AreaCoordinates("PT",39.399865,-8.224450,"Portugal");

        Item olives= new Item(260,"'01450","Olives");
        Element harvested = new Element(5312,"Area harvested");
        Year ano = new Year(2008,1963);
        Area portugal = new Area(174,620,"Portugal");

        Area a = f1.getCloseAreaDetails(39.399865,-8.224450,olives.getItemCode(),harvested.getElementCode(),ano.getYearCode());

        assertEquals(portugal.getArea(), a.getArea());

    }
    @Test
    public void testSucessGetCloseAreaDetails2(){

        AreaCoordinates closeToPortugalCoordinates= new AreaCoordinates("PT",39.399865,-8.224450,"Portugal");

        Item olives= new Item(260,"'01450","Olives");
        Element harvested = new Element(5312,"Area harvested");
        Year ano = new Year(2008,1963);
        Area portugal = new Area(174,620,"Portugal");

        Area a = f2.getCloseAreaDetails(39.399865,-8.224450,olives.getItemCode(),harvested.getElementCode(),ano.getYearCode());

        assertEquals(portugal.getArea(), a.getArea());

    }

    @Test
    public void testSucessGetCloseAreaDetails3(){

        AreaCoordinates closeToPortugalCoordinates= new AreaCoordinates("PT",39.399865,-8.224450,"Portugal");

        Item olives= new Item(260,"'01450","Olives");
        Element harvested = new Element(5312,"Area harvested");
        Year ano = new Year(2008,1963);
        Area portugal = new Area(174,620,"Portugal");

        Area a = f3.getCloseAreaDetails(39.399865,-8.224450,olives.getItemCode(),harvested.getElementCode(),ano.getYearCode());

        assertEquals(portugal.getArea(), a.getArea());

    }

}
