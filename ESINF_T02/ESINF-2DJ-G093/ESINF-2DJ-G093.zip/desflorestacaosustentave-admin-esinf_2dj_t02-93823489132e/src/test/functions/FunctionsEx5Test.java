package functions;

import io.DataSheet;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit tests to functionality related to exercise 5.
 */
public class FunctionsEx5Test {

    private final String EU_SMALL_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_small.csv";
    private final String EU_MEDIUM_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_medium.csv";
    private final String EU_LARGE_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";
    private final String MAIN_EU_SMALL_PATH = "src/resources/Production_Crops_Livestock_FR_GER_IT_PT_SP_shuffle_small.csv";
    private final String ACCUMULATED_VALUES_PATH = "src/resources/AccumulatedValuesTest.csv";

    private DataSheet d1;
    private Functions f1;
    private DataSheet d2;
    private Functions f2;
    private DataSheet d3;
    private Functions f3;
    private DataSheet d4;
    private Functions f4;
    private DataSheet d5;
    private Functions f5;

    @Before
    public void setUp(){
        d1 = new DataSheet();
        d2 = new DataSheet();
        d3 = new DataSheet();
        d4 = new DataSheet();
        d5 = new DataSheet();



        d1.parseBaseDataCSV(ACCUMULATED_VALUES_PATH);
        f1 = new Functions(d1);

        d2.parseBaseDataCSV(MAIN_EU_SMALL_PATH);
        f2 = new Functions(d2);

        d3.parseBaseDataCSV(EU_SMALL_PATH);
        f3 = new Functions(d3);

        d4.parseBaseDataCSV(EU_MEDIUM_PATH);
        f4 = new Functions(d4);

        d5.parseBaseDataCSV(EU_LARGE_PATH);
        f5 = new Functions(d5);
    }


    // Since this algorithm is not determined, the best, worst and average case are going to be tested.

    @Test
    public void testAccumulatedValuesTestCSV(){

        // Finland(180088): 61.92411,25.748151 + France(9648): 46.227638,2.213749
        int result = f1.accumulatedValues(426, 5419, 1981, 45, 50, 70, 2);

        int expected = 189736;

        Assert.assertEquals("The value returned should be: ", expected, result);

        ////////////////////////////////////////////////////////////////////////
        // France(9648): 46.227638,2.213749
        result = f1.accumulatedValues(1025, 5320, 1973, 0, 0, 0, 0);

        expected = 0;

        Assert.assertEquals("The value returned should be: ", expected, result);

        ////////////////////////////////////////////////////////////////////////

        // Denmark(44859): 56.26392,9.501785
        result = f1.accumulatedValues(15, 5419, 1970, 50, 15, 70, 5);

        expected = 44859;

        Assert.assertEquals("The value returned should be: ", expected, result);

        ////////////////////////////////////////////////////////////////////////
        // Hungary(5897): 47.162494,19.503304 + Spain(46): 40.463667,-3.74922 + Germany(4190): 51.165691,10.451526 +
        // Denmark(475311): 56.26392,9.501785 + Czechoslovakia(3303): 49.8037633,49.8037633

        result = f1.accumulatedValues(211, 5510, 2010, 42, 30, 60, 0);

        expected = 5897+4190+475311+3303;

        Assert.assertEquals(expected, result);


    }

    @Test
    public void testMainEuropeSmallFile(){

        int result = f2.accumulatedValues(401, 5419, 1995, -50, 50, 50, -50);
        int expected = 257399;
        Assert.assertEquals(expected, result);

    }

    @Test
    public void testEuropeSmallFile(){

        // Greece(39.074208,21.824312): 515,5510,1966,219000.000000
        int result = f3.accumulatedValues(515, 5510, 1966, 0, 50, 50, 0);

        int expected = 219000;

        Assert.assertEquals(expected, result);

    }

    @Test
    public void testEuropeMediumFile(){
        //Poland(51.919438,19.145136): 1079,5112,2020,15892.000000
        //Croatia(45.1,15.2): 1079, 5112, 2020, 481.000000
        int result = f4.accumulatedValues(1079, 5112, 2020, 0, 20, 52, 0);

        int expected = 15892+481;

        Assert.assertEquals(expected, result);
    }

    @Test
    public void testEuropeLargeFile(){

        //Romania(45.943161,24.96676): 83, 5419, 1980, 13568
        int result = f5.accumulatedValues(83, 5419, 1980, 40, 25, 50, 20);

        int expected = 13568;

        Assert.assertEquals(expected, result);
    }

}
