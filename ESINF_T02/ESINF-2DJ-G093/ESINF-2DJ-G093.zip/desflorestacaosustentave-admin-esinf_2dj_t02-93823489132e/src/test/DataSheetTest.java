import io.DataSheet;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

// TODO: Ver o motivo de não conseguir ler os ficheiros "World" -> "Nenhuma linha foi encontrada".

public class DataSheetTest {

    private final String EU_S_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";
    private final String MAIN_EU_S_PATH = "src/resources/Production_Crops_Livestock_FR_GER_IT_PT_SP_shuffle_small.csv";

    private final String EU_M_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_medium.csv";
    private final String EU_L_PATH = "src/resources/Production_Crops_Livestock_EU_shuffle_large.csv";

    private DataSheet d1 = new DataSheet();
    private DataSheet d2 = new DataSheet();
    private DataSheet d3 = new DataSheet();

    @Test
    public void testParseEuropeFiles(){
        d1.parseBaseDataCSV(EU_S_PATH);
    }

    @Test
    public void testParseMainEuropeFiles(){
        d2.parseBaseDataCSV(MAIN_EU_S_PATH);
    }

    @Test
    public void testParseAreaLocations(){d1.parseAreaLocations();}
}
