package model;

import domain.Item;
import tree.BST;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class AccumulatedValues implements Comparable<AccumulatedValues> {

    private Item item;
    private BST<ElementYearValuesArea> areaElementYearValuesBST;

    public AccumulatedValues(Item item, BST<ElementYearValuesArea> itemsElementYearValuesBST) {
        this.item = item;
        this.areaElementYearValuesBST = itemsElementYearValuesBST;
    }

    public Item getItem() {
        return item;
    }

    public BST<ElementYearValuesArea> getElementYearValuesAreaBST() {
        return areaElementYearValuesBST;
    }

    @Override
    public int compareTo(AccumulatedValues o) {
        return this.item.getItemCode().compareTo(o.item.getItemCode());
    }
}
