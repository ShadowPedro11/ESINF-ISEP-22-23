package model;

import domain.Area;
import domain.Item;
import domain.Value;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class ValueArea implements Comparable<ValueArea> {

    private Area area;

    private Value value;

    public ValueArea(Area area, Value value) {
        this.area = area;
        this.value = value;
    }

    public Area getArea() {
        return area;
    }

    public Value getValue() {
        return value;
    }

    public void setValue(Value value) {
        this.value = value;
    }

    @Override
    public int compareTo(ValueArea o) {
        return area.getArea().compareTo(o.area.getArea());
    }
}
