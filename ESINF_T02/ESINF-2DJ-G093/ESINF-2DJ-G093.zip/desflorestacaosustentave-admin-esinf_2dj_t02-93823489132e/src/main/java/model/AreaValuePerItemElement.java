package model;

import tree.BST;

import java.util.Comparator;
/**
 * @author : Pedro Pereira - 1211131
 **/
public class AreaValuePerItemElement implements Comparable<AreaValuePerItemElement> {
    private ItemsElements itemsElements;
    private BST<AreaYearValue> areaYearValueBST;

    public AreaValuePerItemElement(ItemsElements itemsElements, BST<AreaYearValue> areaYearValueBST) {
        this.itemsElements = itemsElements;
        this.areaYearValueBST = areaYearValueBST;
    }

    public ItemsElements getItemsElements() {
        return itemsElements;
    }

    public BST<AreaYearValue> getAreaYearValueBST() {
        return areaYearValueBST;
    }

    @Override
    public int compareTo(AreaValuePerItemElement o) {
        return Comparator.comparing(AreaValuePerItemElement::getItemsElements).compare(this,o);
    }

    @Override
    public String toString() {
        return itemsElements.toString()+"BST<AreaYearValue>\n";
    }
}
