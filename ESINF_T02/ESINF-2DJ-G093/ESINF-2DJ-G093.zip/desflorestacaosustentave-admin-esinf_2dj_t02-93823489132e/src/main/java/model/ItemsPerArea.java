package model;

import domain.Area;
import domain.Item;
import tree.AVL;
import tree.BST;


public class ItemsPerArea implements Comparable<ItemsPerArea>{

    private Area area;
    private BST<Item> itemBST;

    public ItemsPerArea(Area area, BST<Item> itemBST) {
        this.area = area;
        this.itemBST = new AVL<>();
    }

    public Area getArea() {
        return area;
    }

    public BST<Item> getItemBST() {
        return itemBST;
    }

    @Override
    public int compareTo(ItemsPerArea o) {
        return area.getAreaCode().compareTo(o.area.getAreaCode());
    }
}
