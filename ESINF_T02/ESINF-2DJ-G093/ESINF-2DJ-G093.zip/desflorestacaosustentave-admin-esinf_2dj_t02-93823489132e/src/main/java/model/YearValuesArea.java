package model;

import domain.Value;
import domain.Year;
import tree.AVL;
import tree.BST;
import tree.KDTree;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class YearValuesArea implements Comparable<YearValuesArea> {

    private Year year;

    private BST<ValueArea> valueAreaBST;
    private KDTree<ValueArea> valueAreaKDTree;

    public YearValuesArea(Year year, BST<ValueArea> valueAreaBST) {
        this.year = year;
        this.valueAreaBST = new AVL<>();
        this.valueAreaKDTree = new KDTree<>();
    }

    public Year getYear() {
        return year;
    }

    public BST<ValueArea> getValueAreaBST() {
        return valueAreaBST;
    }

    public KDTree<ValueArea> getValueAreaKDTree() {
        return valueAreaKDTree;
    }

    @Override
    public int compareTo(YearValuesArea o) {
        return year.getYearCode().compareTo(o.year.getYearCode());
    }
}
