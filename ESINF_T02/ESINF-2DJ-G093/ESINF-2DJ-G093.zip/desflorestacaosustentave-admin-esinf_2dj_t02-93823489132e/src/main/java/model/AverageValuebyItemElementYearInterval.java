package model;

import domain.Element;
import domain.Item;
import domain.Year;

import java.util.Comparator;
import java.util.Objects;

/**
 * @author : Pedro Pereira - 1211131
 *
 **/
public class AverageValuebyItemElementYearInterval implements Comparable<AverageValuebyItemElementYearInterval> {

    private Year year1;
    private Year year2;
    private Item item;
    private Element element;
    private double avgValue;

    public AverageValuebyItemElementYearInterval(Year year1, Year year2, Item item, Element element, double avgValue) {
        this.year1 = year1;
        this.year2 = year2;
        this.item = item;
        this.element = element;
        this.avgValue = avgValue;
    }

    public Year getYear1() {
        return year1;
    }

    public Year getYear2() {
        return year2;
    }

    public Item getItem() {
        return item;
    }

    public Element getElement() {
        return element;
    }

    public double getAvgValue() {
        return avgValue;
    }

    @Override
    public String toString() {
        return String.format("%d...%d,%s,%s,%.3f\n",this.year1.getYear(),this.year2.getYear(),this.getItem().getItem(),this.getElement().getElement(),this.avgValue);
    }

    @Override
    public int compareTo(AverageValuebyItemElementYearInterval o) {
        return Comparator.comparing(AverageValuebyItemElementYearInterval::getAvgValue).compare(this,o);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AverageValuebyItemElementYearInterval ex2Return = (AverageValuebyItemElementYearInterval) o;
        return Objects.equals(String.format("%.3f",ex2Return.avgValue), String.format("%.3f",avgValue)) && Objects.equals(year1.getYear(), ex2Return.year1.getYear()) && Objects.equals(year2.getYear(), ex2Return.year2.getYear()) && Objects.equals(item.getItem(), ex2Return.item.getItem()) && Objects.equals(element.getElement(), ex2Return.element.getElement());
    }

    @Override
    public int hashCode() {
        return Objects.hash(year1, year2, item, element, avgValue);
    }
}
