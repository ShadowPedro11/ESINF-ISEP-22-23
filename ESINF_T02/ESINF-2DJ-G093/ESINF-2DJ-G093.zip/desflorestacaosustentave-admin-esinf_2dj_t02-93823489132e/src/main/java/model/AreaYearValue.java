package model;

import domain.Area;
import domain.Value;
import domain.Year;
import tree.BST;

import java.util.Comparator;
/**
 * @author : Pedro Pereira - 1211131
 **/
public class AreaYearValue implements Comparable<AreaYearValue> {
    private Year year;
    private BST<ValueArea> valueAreaBST;

    public AreaYearValue(Year year, BST<ValueArea> valueAreaBST) {
        this.year = year;
        this.valueAreaBST = valueAreaBST;
    }

    public Year getYear() {
        return year;
    }

    public int getYearYear() {
        return year.getYear();
    }

    public BST<ValueArea> getValueAreaBST() {
        return valueAreaBST;
    }

    @Override
    public int compareTo(AreaYearValue o) {
        return Comparator.comparing(AreaYearValue::getYearYear).compare(this,o);
    }
}
