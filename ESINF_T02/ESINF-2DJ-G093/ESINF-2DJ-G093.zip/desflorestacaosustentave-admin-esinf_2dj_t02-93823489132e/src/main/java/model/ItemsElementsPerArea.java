package model;
import domain.Area;
import tree.BST;

import java.util.Objects;

/**
 * @author : Pedro Pereira - 1211131
 **/
public class ItemsElementsPerArea implements Comparable<ItemsElementsPerArea>   {
    private Area area;
    private BST<ItemsElementsAccumulatedValue> itemsElementsBST;

    public ItemsElementsPerArea(Area area, BST<ItemsElementsAccumulatedValue> itemsElementsBST) {
        this.area = area;
        this.itemsElementsBST = itemsElementsBST;
    }

    public Area getArea() {
        return area;
    }

    public BST<ItemsElementsAccumulatedValue> getItemsElementsBST() {
        return itemsElementsBST;
    }

    @Override
    public int compareTo(ItemsElementsPerArea o) {
        return area.getAreaCode().compareTo(o.area.getAreaCode());
    }


    @Override
    public String toString() {
        return "ItemsElementsPerArea{" +
                "area=" + area.getArea() +
                ", itemsElementsBST=" + itemsElementsBST.posOrder() +
                '}';
    }
}
