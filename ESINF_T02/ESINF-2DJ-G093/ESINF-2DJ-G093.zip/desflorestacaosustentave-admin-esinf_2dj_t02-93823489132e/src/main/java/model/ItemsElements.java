package model;
import domain.Element;
import domain.Item;
import java.util.Comparator;
import java.util.Objects;

/**
 * @author : Pedro Pereira - 1211131
 **/
public class ItemsElements implements Comparable<ItemsElements> {
    private Item item;
    private Element element;

    public ItemsElements(Item item, Element element) {
        this.item = item;
        this.element = element;
    }

    public Item getItem() {
        return item;
    }

    public Element getElement() {
        return element;
    }

    public int getItemCode() {
        return item.getItemCode();
    }

    public int getElementCode() {
        return element.getElementCode();
    }

    @Override
    public int compareTo(ItemsElements o) {
        return Comparator.comparing(ItemsElements::getItemCode)
                .thenComparing(ItemsElements::getElementCode)
                .compare(this,o);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemsElements that = (ItemsElements) o;
        return Objects.equals(item, that.item) && Objects.equals(element, that.element);
    }

    @Override
    public int hashCode() {
        return Objects.hash(item, element);
    }

    @Override
    public String toString() {
        return "Item: " + item.getItem() + "| Element: " + element.getElement() + "\n";
    }
}
