package model;

import domain.Area;
import domain.Element;
import domain.Year;
import tree.KDTree;

public class AreaYear implements Comparable<AreaYear> {

    private Year year;
    private KDTree<Area> areaKDTree;

    public AreaYear(Year year) {
        this.year = year;
        areaKDTree= new KDTree<>();
    }

    public domain.Year getYear() {
        return year;
    }

    public KDTree<Area> getAreaKDTree() {
        return areaKDTree;
    }

    @Override
    public int compareTo(AreaYear o) {
        return year.getYearCode().compareTo(o.getYear().getYearCode());
    }
}
