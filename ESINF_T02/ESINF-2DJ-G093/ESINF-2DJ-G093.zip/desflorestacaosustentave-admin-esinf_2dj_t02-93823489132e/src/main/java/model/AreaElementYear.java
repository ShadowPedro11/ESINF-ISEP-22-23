package model;

import domain.Element;
import domain.Item;
import tree.AVL;
import tree.BST;

public class AreaElementYear implements Comparable<AreaElementYear> {

    private Element element;
    private BST<AreaYear> areaYearBST;

    public AreaElementYear(Element element) {
        this.element = element;
        areaYearBST= new AVL<>();
    }

    public Element getElement() {
        return element;
    }

    public BST<AreaYear> getAreaYearBST() {
        return areaYearBST;
    }

    @Override
    public int compareTo(AreaElementYear o) {
        return element.getElementCode().compareTo(o.getElement().getElementCode());
    }

}
