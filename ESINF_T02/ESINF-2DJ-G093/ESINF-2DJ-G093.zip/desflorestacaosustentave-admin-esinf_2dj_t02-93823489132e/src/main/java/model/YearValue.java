package model;

import domain.Value;
import domain.Year;

public class YearValue {
    private Year year;
    private Value value;

    public YearValue(Year year, Value value) {
        this.year = year;
        this.value = value;
    }

    public Year getYear() {
        return year;
    }

    public Value getValue() {
        return value;
    }
}
