package model;

import domain.Element;
import tree.AVL;
import tree.BST;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class ElementYearValuesArea implements Comparable<ElementYearValuesArea> {

    Element element;

    BST<YearValuesArea> yearValuesAreaBST;

    public ElementYearValuesArea(Element element, BST<YearValuesArea> yearValuesAreaBST) {
        this.element = element;
        this.yearValuesAreaBST = new AVL<>();
    }

    public Element getElement() {
        return element;
    }

    public BST<YearValuesArea> getYearValuesAreaBST() {
        return yearValuesAreaBST;
    }

    @Override
    public int compareTo(ElementYearValuesArea o) {
        return element.getElementCode().compareTo(o.element.getElementCode());
    }
}
