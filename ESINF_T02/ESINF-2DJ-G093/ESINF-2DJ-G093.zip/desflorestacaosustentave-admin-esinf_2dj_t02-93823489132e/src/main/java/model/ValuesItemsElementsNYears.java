package model;

import domain.Element;
import domain.Item;
import domain.Value;
import domain.Year;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class ValuesItemsElementsNYears implements Comparable<ValuesItemsElementsNYears> {
    private Value value;
    private Item item;
    private Element element;
    private Year year;

    public ValuesItemsElementsNYears(Value value, Item item, Element element, Year year) {
        this.value = value;
        this.item = item;
        this.element = element;
        this.year = year;
    }

    public Value getValue() {
        return value;
    }

    public Item getItem() {
        return item;
    }

    public Element getElement() {
        return element;
    }

    public Year getYear() {
        return year;
    }

    @Override
    public int compareTo(ValuesItemsElementsNYears o) {
        return 0;
    }
}
