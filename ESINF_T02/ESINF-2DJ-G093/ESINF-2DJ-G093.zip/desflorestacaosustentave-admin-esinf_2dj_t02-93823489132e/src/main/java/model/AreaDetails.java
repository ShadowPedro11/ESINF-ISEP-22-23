package model;

import domain.*;
import tree.AVL;
import tree.BST;

public class AreaDetails implements Comparable<AreaDetails>{

    private Item item;
    private BST<AreaElementYear> areaElementYearBST;


    public AreaDetails(Item item) {
        this.item = item;
        areaElementYearBST= new AVL<>();
    }

    public Item getItem() {
        return item;
    }

    public BST<AreaElementYear> getAreaElementYearBST() {
        return areaElementYearBST;
    }

    @Override
    public int compareTo(AreaDetails o) {
        return item.getItemCode().compareTo(o.getItem().getItemCode());
    }
}
