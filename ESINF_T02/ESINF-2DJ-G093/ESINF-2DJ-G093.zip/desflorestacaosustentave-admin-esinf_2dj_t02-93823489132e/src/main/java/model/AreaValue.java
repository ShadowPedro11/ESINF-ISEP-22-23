package model;

import domain.Area;
import domain.Value;

import java.util.Comparator;
import java.util.Objects;

/**
 * @author : Pedro Pereira - 1211131
 **/
public class AreaValue implements Comparable<AreaValue>{
    private Area area;
    private Value value;

    public AreaValue(Area area, Value value) {
        this.area = area;
        this.value = value;
    }

    public Area getArea() {
        return area;
    }

    public Value getValue() {
        return value;
    }

    public Double getValueOfValue() {
        return value.getValue();
    }


    @Override
    public int compareTo(AreaValue o) {
        return Comparator.comparing(AreaValue::getValueOfValue).compare(this,o);
    }

    @Override
    public String toString() {
        return "AreaValue{" +
                "area=" + area.getArea() +
                ", value=" + value.getValue() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AreaValue areaValue = (AreaValue) o;
        return Objects.equals(area, areaValue.area) && Objects.equals(value, areaValue.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(area, value);
    }
}
