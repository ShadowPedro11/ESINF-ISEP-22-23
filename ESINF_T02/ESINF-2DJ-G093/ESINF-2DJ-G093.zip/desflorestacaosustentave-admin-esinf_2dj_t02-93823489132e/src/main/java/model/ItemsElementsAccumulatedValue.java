package model;
import domain.Element;
import domain.Item;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * @author : Pedro Pereira - 1211131
 **/
public class ItemsElementsAccumulatedValue implements Comparable<ItemsElementsAccumulatedValue> {
    private Item item;
    private Element element;
    List<YearValue> yearValueList;

    public ItemsElementsAccumulatedValue(Item item, Element element, List<YearValue> yearValueList) {
        this.item = item;
        this.element = element;
        this.yearValueList = yearValueList;
    }

    public Item getItem() {
        return item;
    }

    public Element getElement() {
        return element;
    }

    public int getItemCode() {
        return item.getItemCode();
    }

    public int getElementCode() {
        return element.getElementCode();
    }

    public List<YearValue> getYearValueList() {
        return yearValueList;
    }

    @Override
    public int compareTo(ItemsElementsAccumulatedValue o) {
        return Comparator.comparing(ItemsElementsAccumulatedValue::getItemCode)
                .thenComparing(ItemsElementsAccumulatedValue::getElementCode)
                .compare(this,o);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemsElementsAccumulatedValue that = (ItemsElementsAccumulatedValue) o;
        return Objects.equals(item, that.item) && Objects.equals(element, that.element);
    }

    @Override
    public int hashCode() {
        return Objects.hash(item, element);
    }

    @Override
    public String toString() {
        return "Item: " + item.getItem() + "| Element: " + element.getElement() + "\n";
    }
}
