package model;

import domain.Area;
import tree.BST;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : Ricardo Venâncio - 1210828
 **/
public class ValuesItemsElementsYearsPerArea implements Comparable<ValuesItemsElementsYearsPerArea> {

    private Area area;

    private List<ValuesItemsElementsNYears> vieny;

    private BST<ValuesItemsElementsNYears> vienyBST;

    public ValuesItemsElementsYearsPerArea(Area area, List<ValuesItemsElementsNYears> vieny) {
        this.area = area;
        this.vieny = new ArrayList<>();
    }

    public Area getArea() {
        return area;
    }

    public List<ValuesItemsElementsNYears> getVieny() {
        return vieny;
    }

    @Override
    public int compareTo(ValuesItemsElementsYearsPerArea o) {
        return this.area.getArea().compareTo(o.area.getArea());
    }
}
