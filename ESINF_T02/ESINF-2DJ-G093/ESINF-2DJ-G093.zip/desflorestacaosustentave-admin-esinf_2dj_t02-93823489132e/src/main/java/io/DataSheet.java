package io;
import domain.*;
import model.*;
import tree.AVL;
import tree.BST;
import tree.KDTree;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author : Pedro Pereira - 1211131
 * @author : Ricardo Venâncio - 1210828
 **/
public class DataSheet {

    /**
     * Binary tree storing Areas.
     */
    private BST<Area> areaBST;

    /**
     * Binary tree storing Items.
     */
    private BST<Item> itemBST;

    /**
     * Binary tree storing ItemsPerArea.
     */
    private BST<ItemsPerArea> itemsPerAreaBST;

    /**
     * Binary tree storing ValuesItemsElementsYearsPerAreas.
     */
    private BST<ValuesItemsElementsYearsPerArea> valuesItemsElementsYearsPerAreaBST;

    /**
     * Binary tree storing AccumulatedValues.
     */
    private BST<AccumulatedValues> accumulatedValuesBST;

    /**
     * Binary tree storing ItemsElementsPerArea.
     */
    private BST<ItemsElementsPerArea> itemsElementsPerAreaBST;

    /**
     * Binary tree storing AreaValuePerItemElement.
     */
    private BST<AreaValuePerItemElement> areaValuePerItemElementBST;

    /**
     * 2d tree storing AreaCoordinates.
     */
    private KDTree<AreaCoordinates> areaLocation2DTree;

    /**
     * Binary tree storing AreaCoordinates.
     */
    private BST<AreaCoordinates> areaLocationsBST;

    private  BST<AreaDetails> areaDetailsBST;



    /**
     * Recevies data from a .csv file and parse it to many data structures according to the various functionalities in need.
     * @param path to the .csv file.
     */
    public void parseBaseDataCSV(String path){
        parseAreaLocations();
        File f = new File(path);
        if(!f.canRead())
            return;
        try {
            Scanner readfile = new Scanner(f);
            readfile.nextLine();
            while(readfile.hasNextLine()){


                String[] pal = readfile.nextLine().split("[\"|']*,[\"|']+");

                String FLAG;

                if(!pal[11].matches("[0-9]+.[0-9]+")) {
                    FLAG = pal[11].replaceAll("\"", "");
                    pal[11] = "0";
                }else FLAG = pal[12].replaceAll("\"", "");

                final Integer AREA_CODE = Integer.parseInt(pal[0].replaceAll("\"", "")),
                        CODE_M49 = Integer.parseInt(pal[1].replaceAll("\"", "")),
                        ITEM_CODE = Integer.parseInt(pal[3].replaceAll("\"", "")),
                        ELEMENT_CODE = Integer.parseInt(pal[6].replaceAll("\"", "")),
                        YEAR_CODE = Integer.parseInt(pal[8].replaceAll("\"", "")),
                        YEAR = Integer.parseInt(pal[9].replaceAll("\"", ""));

                final double VALUE = Double.parseDouble(pal[11].replaceAll("\"", ""));

                final String AREA = pal[2].replaceAll("\"", ""),
                        CPC_CODE = pal[4].replaceAll("\"", ""),
                        ITEM = pal[5].replaceAll("\"", ""),
                        ELEMENT = pal[7].replaceAll("\"", ""),
                        UNIT = pal[10].replaceAll("\"", "");

                Area area = new Area(AREA_CODE, CODE_M49, AREA);
                Item item = new Item(ITEM_CODE, CPC_CODE, ITEM);
                Value value = new Value(VALUE, UNIT, FLAG) ;
                Element element = new Element(ELEMENT_CODE, ELEMENT);
                Year year = new Year(YEAR, YEAR_CODE);
                addToAreaBST(area);
                addToItemBST(item);
                addToItemsPerAreaBST(area,item);
                addTovaluesItemsElementsYearsPerAreaBST(value,item,element,year,area);
                addAccumulatedValues(area, value, item, element, year);
                addToItemsElementsPerAreaBST(area,item,element,value,year);
                addToAreaValuePerItemElementBST(item,element,area,value,year);
                addToAreaDetailsBST(area,item,element,year);

            }
            readfile.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Computerize and store data from a .csv file in certain data structures.
     */
    public void parseAreaLocations(){
        File f = new File("src/resources/Production_Crops_Livestock_E_AreaCoordinates_shuffled.csv");
        if(!f.canRead())
            return;
        try {
            Scanner sc = new Scanner(f);
            sc.nextLine();
            while(sc.hasNextLine()){
                String[] words = sc.nextLine().split(",");
                String COUNTRY = words[3];
                double LAT = Double.parseDouble(words[1]);
                double LON = Double.parseDouble(words[2]);
                addToAreaCoordinatesBST(new AreaCoordinates(LAT, LON, COUNTRY));
                addToAreaLocationsBST(new AreaCoordinates(LAT, LON, COUNTRY));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    //=================================================================================================================
    // ADDS

    private void addToAreaCoordinatesBST(AreaCoordinates areaCoordinates){
        if(areaLocation2DTree == null) areaLocation2DTree = new KDTree<>();
        Point2D.Double coords = new Point2D.Double(areaCoordinates.getLatitude(), areaCoordinates.getLongitude());
        areaLocation2DTree.insert(areaCoordinates, coords);
    }

    private void addToAreaLocationsBST(AreaCoordinates areaCoordinates){
        if(areaLocationsBST == null) areaLocationsBST = new AVL<>();
        areaLocationsBST.insert(areaCoordinates);
    }

    private void addToAreaBST(Area area){
        if(areaBST == null)
            areaBST = new AVL<>();
        if(findAreaByArea(area.getArea())==null){
            areaBST.insert(area);
        }
    }

    public void addToAreaDetailsBST(Area a,Item i, Element e,Year y){

        if(areaDetailsBST==null)
            areaDetailsBST=new AVL<>();

        AreaDetails ad = areaDetailsBST.find(new AreaDetails(i));
        if(ad==null){
            ad= new AreaDetails(i);
            areaDetailsBST.insert(ad);
        }

        AreaElementYear aey= ad.getAreaElementYearBST().find(new AreaElementYear(e));
        if(aey==null){
            aey=new AreaElementYear(e);
            ad.getAreaElementYearBST().insert(aey);
        }

        AreaYear ay= aey.getAreaYearBST().find(new AreaYear(y));
        if(ay==null){
            ay= new AreaYear(y);
            aey.getAreaYearBST().insert(ay);
        }

        AreaCoordinates ac= areaLocationsBST.find(new AreaCoordinates("",0,0,a.getArea()));
        if(ac!=null){
            ay.getAreaKDTree().insert(a,new Point2D.Double(ac.latitude,ac.longitude));
        }

    }


    /**
     * Adds an item to the respective BST.
     * @param item to add.
     */
    private void addToItemBST(Item item){
        if(itemBST == null)
            itemBST = new AVL<>();
        if(findItemByCode(item.getItemCode())==null){
            itemBST.insert(item);
        }

    }

    /**
     * Adds an ItemsPerArea to it BST.
     * @param area to add.
     * @param item to add
     */
    private void addToItemsPerAreaBST(Area area, Item item){

        if(itemsPerAreaBST == null) itemsPerAreaBST = new AVL<>();

        ItemsPerArea val = findItemsPerArea(area.getArea());
        if(val == null){
            val = new ItemsPerArea(area, new BST<>());
            itemsPerAreaBST.insert(val);
        }
        if(val.getItemBST().find(item) == null)
            val.getItemBST().insert(item);
    }



    private void addTovaluesItemsElementsYearsPerAreaBST(Value v, Item i, Element e, Year y, Area a){
        if(valuesItemsElementsYearsPerAreaBST == null) valuesItemsElementsYearsPerAreaBST = new AVL<>();

        ValuesItemsElementsYearsPerArea val = findValuesItemsElementsYearsPerArea(a.getArea());
        if(val == null){
            val = new ValuesItemsElementsYearsPerArea(a, new ArrayList<>());
            valuesItemsElementsYearsPerAreaBST.insert(val);
        }
        val.getVieny().add(new ValuesItemsElementsNYears(v, i, e, y));

    }

    private void addAccumulatedValues(Area a, Value v, Item i, Element e, Year y){

        if(accumulatedValuesBST == null) accumulatedValuesBST = new AVL<>();

        AccumulatedValues val = findAccumulatedValues(i);
        if(val == null){
            val = new AccumulatedValues(i, new AVL<>());
            accumulatedValuesBST.insert(val);
        }

        ElementYearValuesArea val2 = findElementYearValuesArea(e, val);
        if(val2 == null){
            val2 = new ElementYearValuesArea(e, new AVL<>());
            val.getElementYearValuesAreaBST().insert(val2);
        }

        YearValuesArea val3 = findYearValuesArea(y, val2);
        if(val3 == null){
            val3 = new YearValuesArea(y, new AVL<>());
            val2.getYearValuesAreaBST().insert(val3);
        }

        AreaCoordinates ac = areaLocationsBST.find(new AreaCoordinates("", 0, 0, a.getArea()));
        if(ac == null)
            return;
        Point2D.Double coords = new Point2D.Double(ac.getLatitude(), ac.getLongitude());
        val3.getValueAreaKDTree().insert(new ValueArea(a, v), coords);


    }

    //=================================================================================================================
    //=================================================================================================================
    // FINDS
    private AccumulatedValues findAccumulatedValues(Item i){
        return accumulatedValuesBST.find(new AccumulatedValues(i, null));
    }

    private ElementYearValuesArea findElementYearValuesArea(Element e, AccumulatedValues val){
        return val.getElementYearValuesAreaBST().find(new ElementYearValuesArea(e, null));
    }

    private YearValuesArea findYearValuesArea(Year y, ElementYearValuesArea val2){
        return val2.getYearValuesAreaBST().find(new YearValuesArea(y, null));
    }

    public ValuesItemsElementsYearsPerArea findValuesItemsElementsYearsPerArea(String area){
        Area a = findAreaByArea(area);
        return valuesItemsElementsYearsPerAreaBST.find(new ValuesItemsElementsYearsPerArea(a, null));
    }

    public ItemsPerArea findItemsPerArea(String area){
        Area a = findAreaByArea(area);
        return itemsPerAreaBST.find(new ItemsPerArea(a, null));
    }

    /**
     * Finds an Area (object) through an area (String) passed by argument.
     * @param area to search.
     * @return an Area (object) or a null if it doesn't find anything.
     */
    public Area findAreaByArea(String area){
        return areaBST.find(new Area(0, 0, area));
    }

    /**
     * Searches for an item.
     * @param itemCode to search.
     * @return an Item.
     */
    public Item findItemByCode(int itemCode){
        return itemBST.find(new Item(itemCode, "", ""));
    }

    //=================================================================================================================
    //===============================================================================================================
    //EX02

    private void addToItemsElementsPerAreaBST(Area area, Item item,Element element,Value value,Year year) {
        if (itemsElementsPerAreaBST == null) itemsElementsPerAreaBST = new AVL<>();

        ItemsElementsPerArea itemsElementsPerArea = findItemsElementsPerArea(area);

        if(itemsElementsPerArea == null){
            itemsElementsPerArea = new ItemsElementsPerArea(area,new BST<>());
            itemsElementsPerAreaBST.insert(itemsElementsPerArea);
        }

        if(itemsElementsPerArea.getItemsElementsBST()!=null){
            if(itemsElementsPerArea.getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item,element,null))==null){
                itemsElementsPerArea.getItemsElementsBST().insert(new ItemsElementsAccumulatedValue(item,element,new ArrayList<>()));
                ItemsElementsAccumulatedValue itemsElementsAccumulatedValue = itemsElementsPerArea.getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item,element,null));
                itemsElementsAccumulatedValue.getYearValueList().add(new YearValue(year, value));
            }else {
                ItemsElementsAccumulatedValue itemsElementsAccumulatedValue = itemsElementsPerArea.getItemsElementsBST().find(new ItemsElementsAccumulatedValue(item,element,null));
                itemsElementsAccumulatedValue.getYearValueList().add(new YearValue(year, value));
            }
        }
    }

    public ItemsElementsPerArea findItemsElementsPerArea(Area a){
        return itemsElementsPerAreaBST.find(new ItemsElementsPerArea(a, null));
    }

    //=================================================================================================================
    //==========================================================================================================
    //EX03
    /**
     * Adicionar AreaValuePerItemElement à sua BST.
     *
     * @param item a ser adicionado.
     * @param element a ser adicionado.
     * @param area a ser adicionado.
     * @param value a ser adicionado.
     * @param year a ser adicionado.
     * */
    private void addToAreaValuePerItemElementBST(Item item, Element element, Area area, Value value, Year year) {
        if (areaValuePerItemElementBST == null) areaValuePerItemElementBST = new AVL<>();

        //Item Element -> BST<Year,BST<AREA,VALUE>
        AreaValuePerItemElement areaValuePerItemElement = findAreaValuePerItemElementBST(item,element);

        //if 1st bst in null
        if(areaValuePerItemElement == null){
            // mudei de new BST<> para AVL<> - ricardo
            areaValuePerItemElement = new AreaValuePerItemElement(new ItemsElements(item,element),new AVL<>());
            areaValuePerItemElementBST.insert(areaValuePerItemElement);

            AreaYearValue areaYearValue = new AreaYearValue(year,new AVL<>());
            areaValuePerItemElement.getAreaYearValueBST().insert(areaYearValue);
            areaValuePerItemElement.getAreaYearValueBST().find(areaYearValue).getValueAreaBST().insert(new ValueArea(area,value));
        }else {
            // 2nd bst is null
            AreaYearValue areaYearValue = findAreaYearValue(item,element,year);
            if(areaYearValue==null){
                areaYearValue = new  AreaYearValue(year,new BST<>());
                areaValuePerItemElement.getAreaYearValueBST().insert(areaYearValue);
                areaValuePerItemElement.getAreaYearValueBST().find(areaYearValue).getValueAreaBST().insert(new ValueArea(area,value));
            }else {
                //3rd bst is null
                if(findValueArea(item,element,year,area)==null){
                    areaValuePerItemElement.getAreaYearValueBST().find(areaYearValue).getValueAreaBST().insert(new ValueArea(area,value));
                }else {
                    ValueArea valueArea = areaValuePerItemElement.getAreaYearValueBST().find(areaYearValue).getValueAreaBST().find(new ValueArea(area,value));
                    if (valueArea.getValue().getValue()<value.getValue()){
                        valueArea.setValue(value);
                    }
                }
            }
        }
    }

    /**
     * Encontra AreaValuePerItemElement correspondente a um determinado Item e Element.
     *
     * @param item Item a procurar.
     * @param element Element a procurar.
     *
     * @return uma AreaValuePerItemElement ou null caso não exista.
     * */
    public AreaValuePerItemElement findAreaValuePerItemElementBST(Item item, Element element){
        return areaValuePerItemElementBST.find(new AreaValuePerItemElement(new ItemsElements(item,element),null));
    }
    /**
     * Encontra AreaYearValue correspondente a um determinado Item, Element e Year.
     *
     * @param item Item a procurar.
     * @param element Element a procurar.
     * @param year Year a procurar.
     *
     * @return uma AreaYearValue ou null caso não exista.
     * */
    public AreaYearValue findAreaYearValue(Item item, Element element,Year year){
        return areaValuePerItemElementBST.find(new AreaValuePerItemElement(new ItemsElements(item,element),null)).getAreaYearValueBST().find(new AreaYearValue(year,null));
    }
    /**
     * Encontra uma ValueArea correspondente a um determinado Item, Element, Year e Area.
     *
     * @param item Item a procurar.
     * @param element Element a procurar.
     * @param year Year a procurar.
     *
     * @return uma ValueYear ou null caso não exista.
     * */
    public ValueArea findValueArea(Item item, Element element,Year year,Area area){
        return areaValuePerItemElementBST.find(new AreaValuePerItemElement(new ItemsElements(item,element),null)).getAreaYearValueBST().find(new AreaYearValue(year,null)).getValueAreaBST().find(new ValueArea(area,null));
    }

    //===============================================================================================================

    // BST GETTERS
    public BST<ItemsElementsPerArea> getItemsElementsPerAreaBST() {
        return itemsElementsPerAreaBST;
    }

    public BST<AreaValuePerItemElement> getAreaValuePerItemElementBST() {
        return areaValuePerItemElementBST;
    }

    public BST<AccumulatedValues> getAccumulatedValuesBST() {
        return accumulatedValuesBST;
    }

    public BST<AreaDetails> getAreaDetailsBST() {
        return areaDetailsBST;
    }

    //=================================================================================================================
}