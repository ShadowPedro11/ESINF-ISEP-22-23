package tree;
import java.util.ArrayList;
import java.util.List;

public class Utils {
    /**
     * Mergesort Algorithm
     */
    private static <E extends Comparable<E>> void merge(List<E> S1, List<E> S2, List<E> S) {
        int i = 0, j = 0, k = 0;
        while (i < S1.size() && j < S2.size()) {
            if (S1.get(i).compareTo(S2.get(j)) < 0) {
                S.set(k, S2.get(j));
                k++;
                j++;
            } else {
                S.set(k, S1.get(i));
                k++;
                i++;
            }
        }
        while (i < S1.size()) {
            S.set(k, S1.get(i));
            k++;
            i++;
        }
        while (j < S2.size()) {
            S.set(k, S2.get(j));
            k++;
            j++;
        }

    }

    public static <E extends Comparable<E>> void mergeSort(List<E> S) {
        if (S.size() >= 2) {
            int mid = S.size() / 2;
            List<E> s1 = copyOfRange(S, 0, mid);
            List<E> s2 = copyOfRange(S, mid, S.size());

            mergeSort(s1);
            mergeSort(s2);

            merge(s1, s2, S);
        }

    }

    private static <E extends Comparable<E>> List<E> copyOfRange(List<E> list, int initial, int posFinal) {
        List<E> toReturn = new ArrayList<>();
        for (int i = initial; i < posFinal; i++) {
            toReturn.add(list.get(i));
        }
        return toReturn;
    }

}
