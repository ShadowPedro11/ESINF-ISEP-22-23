package tree;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Comparator;

public class KDTree<T extends Comparable<T>> extends BST<T> {

    // Nested static class for a binary search tree node.
    protected static class Node2D<T> extends Node<T> {
        protected Point2D.Double coords;

        public Node2D(Point2D.Double coords, T info, Node2D<T> left, Node2D<T> right) {
            super(info, left, right);
            this.coords = coords;
        }

        public Point2D.Double getCoords() {
            return coords;
        }

        public void setCoords(Point2D.Double coords) {
            this.coords = coords;
        }
    }

    //----------- end of nested Node class -----------


    protected Node2D<T> root;

    public KDTree() {
        root = null;
    }

    private final Comparator<Node2D<T>> cmpX = Comparator.comparingDouble(o -> o.getCoords().getX());

    private final Comparator<Node2D<T>> cmpY = Comparator.comparingDouble(o -> o.getCoords().getY());

    public void insert(T element, Point2D.Double coords){
        root = insert(root, new Node2D<>(coords, element, null, null), true);
    }

    private Node2D<T> insert(Node2D<T> currentNode, Node2D<T> node, boolean divX){

        if(currentNode == null) return node;

        if(node.coords.equals(currentNode.coords))
            return node;

        int cmpResult = (divX ? cmpX : cmpY).compare(node, currentNode);

        if(cmpResult < 0){
            if(currentNode.getLeft() == null)
                currentNode.setLeft(node);
            else
                insert((Node2D<T>) currentNode.getLeft(), node, !divX);
        }else{
            if(currentNode.getRight() == null)
                currentNode.setRight(node);
            else
                insert((Node2D<T>) currentNode.getRight(), node, !divX);
        }
        return currentNode;
    }

    public T find(Point2D.Double coords){
        return find(root, new Node2D<>(coords, null, null, null), true);
    }

    private T find(Node2D<T> node, Node2D<T> toFind, boolean divX){

        if(node == null) return null;

        if(node.coords.equals(toFind.coords))
            return node.getElement();

        int cmpResult = (divX ? cmpX : cmpY).compare(node, toFind);

        if(cmpResult < 0)
            return find((Node2D<T>) node.getRight(), toFind, !divX);
        else
            return find((Node2D<T>) node.getLeft(), toFind, !divX);
    }

    public T nearestNeighbour(Point2D.Double coords){
        return nearestNeighbour(root, coords, root, true).getElement();
    }

    private Node2D<T> nearestNeighbour(Node2D<T> node, Point2D.Double coords, Node2D<T> closestNode, boolean divX){
        if(node == null) return null;

        double d = Point2D.distanceSq(node.coords.x,node.coords.y, coords.x, coords.y);
        double closestDist = Point2D.distanceSq(closestNode.coords.x, closestNode.coords.y, coords.x, coords.y);

        if(closestDist > d) closestNode = node;

        double delta = divX ? coords.x - node.coords.x : coords.y - node.coords.y;
        double delta2 = delta*delta;

        Node2D<T> node1 = (Node2D<T>) (delta < 0 ? node.getLeft() : node.getRight());
        Node2D<T> node2 = (Node2D<T>) (delta < 0 ? node.getRight() : node.getLeft());

        Node2D<T> n1 = nearestNeighbour(node1, coords, closestNode, !divX);
        Node2D<T> n2 = null;
        if(delta2 < closestDist) n2 = nearestNeighbour(node2, coords, closestNode, !divX);

        if(n1 != null) {
            double n1Distance = Point2D.distanceSq(n1.getCoords().x, n1.getCoords().y, coords.x, coords.y);
            if(n1Distance < closestDist) {
                closestNode = n1;
                closestDist = n1Distance;
            }
        }
        if(n2 != null){
            double n2Distance = Point2D.distanceSq(n2.getCoords().x, n2.getCoords().y, coords.x, coords.y);
            if(n2Distance < closestDist)
                closestNode = n2;
        }
        return closestNode;

    }

    public ArrayList<T> regionSearch(Point2D.Double p1, Point2D.Double p2){
        ArrayList<T> snapshot = new ArrayList<>();
        regionSearch(root, p1, p2, snapshot);
        return snapshot;
    }

    private void regionSearch(Node2D<T> node, Point2D.Double p1, Point2D.Double p2, ArrayList<T> snapshot){

        if(node == null)
            return;

        double x = node.coords.x;
        double y = node.coords.y;

        if(x > p1.x && y < p1.y && x < p2.x && y > p2.y)
            snapshot.add(node.getElement());

        regionSearch((Node2D<T>) node.getLeft(), p1, p2, snapshot);
        regionSearch((Node2D<T>) node.getRight(), p1, p2, snapshot);
    }
}
