package functions;

import domain.Area;
import domain.Element;
import domain.Item;
import domain.Year;
import io.DataSheet;
import model.*;
import tree.Utils;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class Functions {

    private DataSheet d1;

    public Functions(DataSheet d1) {
        this.d1 = d1;
    }

    public Functions() {
    }

    //=================================================================================================================
    //Ex2
    /**
     * Given an Area and a couple of years, returns a list of average values of each couple of Item,Elements
     * @param area and years to search.
     * @return a list with the couple of years, one Element one Item and the respective average value
     */
    public List<AverageValuebyItemElementYearInterval> getEx2(Area area, String years){
        if (area == null || years == null || years.isEmpty()) return null;
        List<AverageValuebyItemElementYearInterval> ex2List = new ArrayList<>();
        List<Year> yearList = formatYear(years);
        Year year1 = yearList.get(0);
        Year year2 = yearList.get(1);
        ItemsElementsPerArea itemsElementsPerArea = d1.findItemsElementsPerArea(area);
        Iterable<ItemsElementsAccumulatedValue> itemsElementsPerAreaList = itemsElementsPerArea.getItemsElementsBST().posOrder();

        for (ItemsElementsAccumulatedValue c: itemsElementsPerAreaList){
            double average = getAverageValue(c,year1,year2);
            ex2List.add(new AverageValuebyItemElementYearInterval(year1, year2, c.getItem(), c.getElement(), average));
        }

        Utils.mergeSort(ex2List);
        return ex2List;
    }


    /**
     * O metodo retorna a media dos values por cada item e element que se encontrem num determinado intervalo de anos
     * @param itemsElementsAccumulatedValue os valores dos values por cada item e element
     * @param year1 o ano inicial
     * @param year2 o ano final
     * @return a media dos valores agreagados dos values
     */
    public double getAverageValue(ItemsElementsAccumulatedValue itemsElementsAccumulatedValue,Year year1,Year year2){
        if( itemsElementsAccumulatedValue==null || itemsElementsAccumulatedValue.getYearValueList()==null){
            return 0;
        }
        List<YearValue> yearValueList = itemsElementsAccumulatedValue.getYearValueList();

        double average = 0.0;
        int occ = 0;


        for (YearValue c: yearValueList){

            if (year1.getYear()<=c.getYear().getYear() && c.getYear().getYear()<=year2.getYear()){
                average=average+c.getValue().getValue();
                occ++;
            }
        }


         if(occ==0){
             return 0;
         }else {
             return average/occ;
         }
    }


    /**
     * Este metodo retorna uma lista com dois anos
     * passa do formato "[1990,2010]" para dois inteiros
     * @param years no formato em string
     * @return a lista com os dois anos
     */
    public List<Year> formatYear(String years){
        List<Year> yearList = new ArrayList<>();
        formatYear(yearList,years);
        return yearList;
    }


    /**
     * Este metodo faz a conversão do ano em string para dois inteiros
     * @param yearList a lista para acresentar os anos
     * @param years os anos no formato em string
     */
    private void formatYear(List<Year> yearList,String years){
        String[] a = years.split(",");
        a[0]=a[0].substring(1);
        a[1]=a[1].substring(0,4);
        Year yearInitial = new Year(Integer.parseInt(a[0]),Integer.parseInt(a[0]));
        Year yearEnd = new Year(Integer.parseInt(a[1]),Integer.parseInt(a[1]));
        yearList.add(yearInitial);
        yearList.add(yearEnd);
    }

    //=================================================================================================================
    //Ex3
    /**
     *Para um determinado Item, Element e N (número de Areas que são desejadas obter) vai
     * obter as top-N Areas com maior valor no último ano registado no conjunto de dados para aquele Element.
     *
     * @param item é um determinado Item desejado.
     * @param element é um determinado Element desejado.
     * @param n é o número de Areas que são desejadas obter.
     *
     * @return uma lista com as top-N Areas e os seus Values para um determinado Item e Element
     * */

    public List<AreaValue> getTopNAreas(Item item, Element element, Integer n){
        if (item == null || element == null || n == null || n <= 0) return null;

        List<AreaValue> areaValuesList = new ArrayList<>();
        AreaValuePerItemElement areaValuePerItemElement = d1.findAreaValuePerItemElementBST(item, element);
        if (areaValuePerItemElement == null) return null;
        //sort
        AreaYearValue areaYearValue1 = areaValuePerItemElement.getAreaYearValueBST().biggestElement();

        AreaYearValue areaYearValue2 = areaValuePerItemElement.getAreaYearValueBST().find(new AreaYearValue(areaYearValue1.getYear(),null));
        Iterable<ValueArea> areaValueIterable = areaYearValue2.getValueAreaBST().posOrder();

        for (ValueArea c: areaValueIterable){
            if(n!=0) {
                areaValuesList.add(new AreaValue(c.getArea(), c.getValue()));
                n--;
            }
        }

        //get top n
        return areaValuesList;
    }

    //=================================================================================================================
    //Ex4


    public Area getCloseAreaDetails(double lat, double lon, int itemCode, int elementCode, int yearCode){

        AreaDetails ad = d1.getAreaDetailsBST().find(new AreaDetails(new Item(itemCode,"","")));
        if(ad== null)
            return null;
        AreaElementYear aey = ad.getAreaElementYearBST().find(new AreaElementYear(new Element(elementCode,"")));
        if(aey==null)
            return null;
        AreaYear ay = aey.getAreaYearBST().find(new AreaYear(new Year(0,yearCode)));
        if(ay==null)
            return null;

        return ay.getAreaKDTree().nearestNeighbour(new Point2D.Double(lat,lon));

    }
    //=================================================================================================================
    //Ex5

    /**
     * For an item code, element code, year code and a certain area, returns the accumulated production values.
     * @param itemCode to filter.
     * @param elementCode to filter.
     * @param yearCode to filter.
     * @param iniLat to filter.
     * @param iniLon to filter.
     * @param finLat to filter.
     * @param finLon to filter.
     * @return accumulated production values.
     */
    public int accumulatedValues(int itemCode, int elementCode, int yearCode, double iniLat,
                                                        double iniLon, double finLat,
                                                        double finLon){
        AccumulatedValues av = d1.getAccumulatedValuesBST().find(
                new AccumulatedValues(new Item(itemCode, "", ""),
                        null));

        if(av == null)
            return 0;

        ElementYearValuesArea eyv = av.getElementYearValuesAreaBST().find(
                new ElementYearValuesArea(new Element(elementCode, ""),
                        null));

        if(eyv == null)
            return 0;

        YearValuesArea yv = eyv.getYearValuesAreaBST().find(
                new YearValuesArea(new Year(0, yearCode),
                        null));

        if(yv == null)
            return 0;

        Point2D.Double p1, p2;
        p1 = new Point2D.Double(iniLat, iniLon);
        p2 = new Point2D.Double(finLat, finLon);

        List<ValueArea> list = yv.getValueAreaKDTree().regionSearch(p1, p2);

        int sum=0;
        for(ValueArea va : list)
            sum += va.getValue().getValue();

        return sum;
    }

}
