package domain;

import java.util.Objects;

public class Flag implements Comparable<Flag> {

    public char flag;
    public String decription;

    public Flag(char flag, String decription) {
        this.flag = flag;
        this.decription = decription;
    }

    public char getFlag() {
        return flag;
    }

    public String getDecription() {
        return decription;
    }

    @Override
    public int compareTo(Flag o) {
        return Character.compare(this.flag, o.flag);
    }

    @Override
    public String toString() {
        return "Flag{" +
                "flag=" + flag +
                ", decription='" + decription + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flag flag1 = (Flag) o;
        return flag == flag1.flag && Objects.equals(decription, flag1.decription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(flag, decription);
    }
}
