package domain;

import java.util.Objects;

public class Year {
    private Integer year;
    private Integer yearCode;

    public Year(Integer year, Integer yearCode) {
        this.year = year;
        this.yearCode = yearCode;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getYearCode() {
        return yearCode;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Year year1 = (Year) o;
        return Objects.equals(year, year1.year) && Objects.equals(yearCode, year1.yearCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(year, yearCode);
    }
}
