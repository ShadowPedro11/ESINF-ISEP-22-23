package domain;

import java.util.Objects;

public class Item implements Comparable<Item> {

    private Integer itemCode;
    private String itemCPC;
    private String item;

    public Item(Integer itemCode, String itemCPC, String item) {
        this.itemCode = itemCode;
        this.itemCPC = itemCPC;
        this.item = item;
    }

    public Integer getItemCode() {
        return itemCode;
    }

    public String getItem() {
        return item;
    }

    @Override
    public int compareTo(Item o) {
        return itemCode.compareTo(o.itemCode);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Item item1 = (Item) o;
        return Objects.equals(itemCode, item1.itemCode) && Objects.equals(itemCPC, item1.itemCPC) && Objects.equals(item, item1.item);
    }

    @Override
    public int hashCode() {
        return Objects.hash(itemCode, itemCPC, item);
    }
}
