package domain;

import java.util.Objects;

public class Area implements Comparable<Area> {

    private Integer areaCode;
    private Integer codeM49;
    private String area;

    public Area(Integer areaCode, Integer codeM49, String area) {
        this.areaCode = areaCode;
        this.codeM49 = codeM49;
        this.area = area;
    }

    public Integer getAreaCode() {
        return areaCode;
    }

    public String getArea() {
        return area;
    }

    @Override
    public int compareTo(Area o) {
        return area.compareTo(o.area);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Area area1 = (Area) o;
        return Objects.equals(areaCode, area1.areaCode) && Objects.equals(codeM49, area1.codeM49) && Objects.equals(area, area1.area);
    }

    @Override
    public int hashCode() {
        return Objects.hash(areaCode, codeM49, area);
    }
}
