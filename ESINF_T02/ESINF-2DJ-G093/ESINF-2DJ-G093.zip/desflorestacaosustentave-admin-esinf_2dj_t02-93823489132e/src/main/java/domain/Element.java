package domain;

import java.util.Objects;

public class Element {

    private Integer elementCode;
    private String element;

    public Element(Integer elementCode, String element) {
        this.elementCode = elementCode;
        this.element = element;
    }

    public Integer getElementCode() {
        return elementCode;
    }

    public String getElement() {
        return element;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Element element1 = (Element) o;
        return Objects.equals(elementCode, element1.elementCode) && Objects.equals(element, element1.element);
    }

    @Override
    public int hashCode() {
        return Objects.hash(elementCode, element);
    }
}
