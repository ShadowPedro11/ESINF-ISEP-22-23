package domain;

import java.util.Objects;

public class Value implements Comparable<Value> {

    private Double value;
    private String unit;
    private String flag;

    public Value(Double value, String unit, String flag) {
        this.value = value;
        this.unit = unit;
        this.flag = flag;
    }

    public Double getValue() {
        return value;
    }

    public String getUnit() {
        return unit;
    }

    public String getFlag() {
        return flag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Value value1 = (Value) o;
        return Objects.equals(value, value1.value) && Objects.equals(unit, value1.unit) && Objects.equals(flag, value1.flag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value, unit, flag);
    }

    @Override
    public int compareTo(Value o) {
        return Double.compare(value, o.value);
    }
}
