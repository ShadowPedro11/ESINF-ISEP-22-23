package domain;
public class AreaCoordinates implements Comparable<AreaCoordinates> {
    public String country;
    public double latitude;
    public double longitude;
    public String area;

    public AreaCoordinates(String country, double latitude, double longitude, String area) {
        this.country = country;
        this.latitude = latitude;
        this.longitude = longitude;
        this.area = area;
    }

    public AreaCoordinates(double latitude, double longitude, String area) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.area = area;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getArea() {
        return area;
    }

    @Override
    public int compareTo(AreaCoordinates o) {
        return this.area.compareTo(o.area);
    }
}
